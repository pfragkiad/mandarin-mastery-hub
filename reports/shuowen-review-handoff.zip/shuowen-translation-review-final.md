# Shuowen Jiezi — Corrected English Translation and Editorial Review Handoff

**Date:** 2026-11-22  
**Recipient:** Author/editor agent responsible for the 9,833-entry corpus  
**Base:** `shuowen-english-review.txt`  
**Corrected working copy:** `shuowen-english-corrected.txt`  
**Status:** **PARTIAL, evidence-led review; not a full philological certification**

> **Implementation instruction:** Use the corrected working copy for the English translation updates. The working copy also contains 28 source-text changes, so do **not** overwrite a canonical Chinese source without reviewing the original-vs-edited readings in `shuowen-source-restorations.csv`. All original Chinese readings are preserved in the full change log and original input file.

## 1. Executive result — corrections already applied

| Metric | Result |
|:---|---:|
| Input and output entries | 9,833 |
| Unique entry keys, unchanged | 9,833 |
| Entries whose English changed | 1,938 |
| Entries whose Chinese source text changed | 28 |
| Entries changed in any respect | 1,943 |
| Initially marked `[UNCERTAIN]` | 915 |
| Uncertainty flags cleared | 16 |
| Still marked `[UNCERTAIN]` | 899 |

**Interpretation:** The 1,938 English edits combine repeated terminology/formatting standardization with substantive translations. **They are not 1,938 independently validated scholarly translations.** The 28 changes to Chinese include 21 independently sourced restorations, six documented historical/editorial emendations and one export-cleanup change. All 9,833 keys remain stable and consecutive.

**Data integrity:** The original corpus is unchanged, including its historical source readings. The corrected export contains one entry per line under the original `KEY: shuowen:N || CHINESE: ... || ENGLISH DRAFT ...` format. A machine-readable complete changed-row comparison is in `shuowen-reviewed-entry-diff.csv`. The source-only editorial rationale and citations are in `shuowen-source-restorations.csv`. The more detailed field-level operations are in `shuowen-editorial-changes.jsonl` and `shuowen-review-changes.jsonl`.

## 2. Editorial rules for the agent

1. **Preserve identifiers.** Do not re-index, deduplicate by headword, reorder, or discard entries. Keep keys `shuowen:1` through `shuowen:9833`.
2. **Separate witness from emendation.** An attested reading in the received *Da Xu* edition must remain recoverable, even when a scholarly commentary proposes a better character. Store the emendation in an independent field/note if the application supports it. A translation may follow an emendation only when the editorial choice is disclosed.
3. **Keep uncertain status honest.** Do not turn the remaining 899 flags into “verified” merely because terminology was normalized. Clear a flag only after case-specific analysis of the gloss or quoted source.
4. **Distinguish *Shuowen* analysis from contemporary paleography.** “Formed from ...” translates Xu Shen’s graphic account, not a modern archaeological claim about the earliest origin of the character.
5. **Do not auto-fix unusual Chinese graphs by Unicode simplification.** Source data has demonstrable substituted rare graphs (chemical symbols and simplified silk-radical glyphs). For any replacement, document a witness and preserve the original string.
6. **Keep English translations independently authored.** Use external English translations as comparison evidence only, respecting redistribution licenses. Quotations from other English translations should not be copied wholesale.
7. **Separate linguistic content from presentation.** Keep Chinese glyphs and established place names intact in the canonical data. Pinyin or localized display labels belong in presentation metadata, unless explicitly supplied by the historical quotation.

## 3. Complete list of Chinese-source changes applied (28 operations)

The following is **a complete enumeration of changes to the Chinese source field**, not a sample. Short quoted sequences in this table are reproduced exactly for textual comparison; they are intentionally not annotated with pinyin within the string, as doing so would alter the reading being compared.

| Key | Original sequence | Edited sequence | Classification | Reason / external reference |
|:---|:---|:---|:---|:---|
| `shuowen:974` | `从吅、红` | `从吅、𠦆` | Independent text / reference | The reported simplified 红 is a substituted/mangled rare component; CUHK has 𠦆. [CUHK](https://humanum.arts.cuhk.edu.hk/Lexis/lexi-mf/search.php?word=%E5%96%AE) |
| `shuowen:1565` | `（纤）也` | `稱也` | Independent text / reference | MoE and Duan both support 稱也, not slender/fine. [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=42363) [CText](https://ctext.org/wiki.pl?chapter=397394&if=gb) |
| `shuowen:2118` | `钉 —` | `䀘 —` | Independent text / reference | Confirmed headword 䀘 in independent Shuowen transcription. Cannot be metal-radical 钉. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/04) |
| `shuowen:2280` | `東方曰钕` | `東方曰甾` | Independent text / reference | The source East-region variant appears as 甾 in the independent transcription, not neodymium 钕. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/04) |
| `shuowen:2333` | `夏羊牡曰羭` | `夏羊牝曰羭` | Duan/editorial emendation | Duan emends Da Xu 牡 to 牝; variant is documented explicitly by Taiwan MoE. This is a deliberate edition choice, not silent correction. [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=67362) |
| `shuowen:2425` | `𪀐绉` | `𪀐鵖` | Independent text / reference | Independent bird-radical Shuowen text names 𪀐鵖. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/04) |
| `shuowen:2426` | `绉 — 𪀐绉` | `鵖 — 𪀐鵖` | Independent text / reference | The bird headword is 鵖 (bird radical), not simplified silk character 绉. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/04) |
| `shuowen:2600` | `纻，象形` | `𡇒，象形` | Independent text / reference | The pictographic stomach component is 𡇒 in the independent edition. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/04) [CUHK](https://humanum.arts.cuhk.edu.hk/Lexis/lexi-mf/search.php?word=%E8%83%83) |
| `shuowen:2605` | `钋 —` | `膺 —` | Independent text / reference | Independent Shuowen text has 膺 with definition chest. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/04) [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=36440) |
| `shuowen:3037` | `纸上` | `𠃑上` | Independent text / reference | Independent Shuowen transcription reads 𠃑, not simplified paper 纸. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/05) [CText](https://ctext.org/shuo-wen-jie-zi/kao-bu) |
| `shuowen:3257` | `从亼从绁。绁` | `从亼从乁。乁` | Independent text / reference | Independent edition uses 乁 as ancient graph for 及. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/05) |
| `shuowen:3308` | `绁，绁` | `乁，乁` | Independent text / reference | Source contains duplicated substituted form; independent transcription uses 乁. [CUHK](https://humanum.arts.cuhk.edu.hk/Lexis/lexi-mf/searchShuowen.php?field=1%2C2%2C3%2C4%2C5%2C6%2C7&page=3&q=%E5%9E%A3) |
| `shuowen:3670` | `绂，象形` | `𦫳，象形` | Independent text / reference | Independent wood-radical text reads 𦫳. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/06) |
| `shuowen:3671` | `徙土纪` | `徙土輂` | Independent text / reference | Independent source reads 輂 as soil transport apparatus; Duan suggests this clause may belong under a neighboring entry. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/06) [CText](https://ctext.org/wiki.pl?chapter=524468&if=en) |
| `shuowen:3692` | `钌也` | `篋也` | Independent text / reference | Independent wood-radical text and Taiwan MOE have 篋 (box). [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/06) [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=88203) |
| `shuowen:4605` | `钍 —` | `寘 —` | Independent text / reference | MOE confirms 寘 in Shuowen supplement; chemical-element glyph 钍 impossible in context. [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=56734) |
| `shuowen:5492` | `讀若钙` | `讀若兜` | Independent text / reference | MOE and independent dictionaries have 兜 as pronunciation comparator. [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=102915) [Reference](https://www.hanyuguoxue.com/zh-hant/shuowen/zi-161912) |
| `shuowen:5525` | `钐 — 钐钐` | `𣣳 — 𣣳𣣳` | Independent text / reference | The primary source and Taiwan MOE independently read the breath graph 𣣳, NOT 𣤁. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/08) [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=89137) |
| `shuowen:7405` | `水轉轂也` | `水轉穀也` | Editorial lexical variant | Meaning is moving grain by water, using the 穀 witness; another received text has 轂 and is preserved in patch log. [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=24868) [MOE](https://dict.revised.moe.edu.tw/dictView.jsp?ID=9528&la=0&powerMode=0) |
| `shuowen:7891` | `挈門壯也` | `挈門牡也` | Editorial lexical variant | The door-bolt reading 牡 is supported by variant source; 壯 is a plausible transcription error. [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=59217) |
| `shuowen:7892` | `卻至挑夭` | `卻至挑天` | Classical-quotation correction | Duan points to the Guoyu version with 挑天. The source rendering 夭 appears incorrect. [Shuowen.org](https://www.shuowen.org/view/7892) |
| `shuowen:8436` | `甲革甚質` | `甲革椹質` | Classical-quotation correction | Zhouli states 椹質, wooden practice targets, not 甚質 (very hard). [Wikisource](https://zh.wikisource.org/zh-hant/%E5%91%A8%E7%A6%AE/%E5%A4%8F%E5%AE%98%E5%8F%B8%E9%A6%AC) |
| `shuowen:8950` | `终 —` | `䶱 —` | Independent text / reference | 䶱 is attested as turtle name under 龜 radical; it is NOT 𪛇. [CText](https://ctext.org/shuo-wen-jie-zi/gui-bu2/zh) [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/13) |
| `shuowen:8973` | `从绅，绅` | `从𠄎，𠄎` | Independent text / reference | Independent Shuowen transcription gives 𠄎, ancient graph of 及. [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/13) |
| `shuowen:9111` | `细 —` | `墾 —` | Independent text / reference | MOE confirms the character meaning plow/reclaim land with 土+豤 is 墾, not 细. [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=8526) |
| `shuowen:9440` | `从斤新聲` | `从斤𣓀聲` | Duan/editorial emendation | Duan version and Chen Changzhi edition has 𣓀 as sound element; received editions also preserve 新聲. [Reference](https://www.cidianwang.com/shuowenjiezi/xin1569.htm) [Shuowen.org](https://www.shuowen.org/view/9440) |
| `shuowen:9666` | `纷聲。纷，` | `䒣聲。𠍳，` | Independent text / reference | Independent transcription distinguishes 䒣 (phonetic) from 𠍳 (large-seal 嗌). [Wikisource](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/14) [CUHK](https://humanum.arts.cuhk.edu.hk/Lexis/lexi-mf/search.php?word=%E9%9A%98) |
| `shuowen:9459` | `\\t酋矛` | `酋矛` | Export cleanup | Remove leaked tab escape before source text; no lexical change.  |

### 3.1 Source corrections that must remain explicitly editorial

- **`shuowen:2333`**: the original witness has **牡 (mǔ, male)** but Duan Yucai recommends **牝 (pìn, female)** for **羭 (yú)**. The corrected working copy adopts Duan’s reading, which must be marked as **editorial**, not as an undisputed OCR correction. The [Taiwan Ministry of Education variant dictionary](https://dict.variants.moe.edu.tw/dictView.jsp?ID=67362) records the textual distinction.
- **`shuowen:7405`**: the working copy adopts **穀 (gǔ, grain)** over **轂 (gǔ, wheel hub)** for the definition of **漕 (cáo)**. Both readings need to remain traceable; [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=24868) supports grain transport.
- **`shuowen:7891`**: the edited interpretation uses **門牡 (ménmǔ, gate bolt)** instead of transmitted **門壯 (ménzhuàng)**. Treat as a **variant reading** and retain the initial version in the apparatus. [MOE source](https://dict.variants.moe.edu.tw/dictView.jsp?ID=59217).
- **`shuowen:9440`**: the corrected phonetic element **𣓀** is an edition-dependent analysis of **新 (xīn)**; the transmitted version **新聲 (xīn shēng)** must remain recorded. [Comparison](https://www.cidianwang.com/shuowenjiezi/xin1569.htm). The remaining uncertainty flag is intentionally retained.
- **`shuowen:7892`** and **`shuowen:8436`**: normalized historical quotations against the parallel *Guoyu* and *Zhouli* texts. These are **quoted-text emendations**, not simply changed English punctuation. Compare the [*Zhouli* archery passage](https://zh.wikisource.org/zh-hant/%E5%91%A8%E7%A6%AE/%E5%A4%8F%E5%AE%98%E5%8F%B8%E9%A6%AC).

## 4. Substantive English translations already fixed

These are selected editorial revisions in addition to the glyph-restoration-dependent changes. They are already reflected in `shuowen-english-corrected.txt`; **do not apply them a second time**.

| Key(s) | Identified problem | Revised meaning / treatment |
|:---|:---|:---|
| `shuowen:134` | Ritual rice motif flattened to generic grains | Rendered powdered-rice emblems in the quotation. |
| `shuowen:2104` | Ruler of Zheng called “Duke” for 伯 | Corrected to **Earl**. |
| `shuowen:2814` | 七十 mistranslated as “seven in seventy” tax | Corrected to a **70-mu field system**; detailed tax semantics remain uncertain. |
| `shuowen:3231` | 食臭 generalized as ordinary food odor | Corrected to **spoiled-food odor**; uncertainty retained. |
| `shuowen:3613` | Yijing 振恆 passage misread as “deep-rooted” | Corrected quotation to **restless persistence**. |
| `shuowen:4013, 4016–4019, 5829, 5868` | 馮翊 romanized Pingyi | Corrected to **Fengyi**. |
| `shuowen:4052` | 世祖 treated as founding ancestor | Identified **Emperor Shizu (Guangwu of Han)**. |
| `shuowen:4088, 5165` | 犍爲 romanized Qianwei | Corrected to **Jianwei**. |
| `shuowen:4970` | 侗/恫 in Odes misread as lack of knowledge | Translated as **grieved**. |
| `shuowen:6385` | 衛侯燬 mislabeled Duke Hui | Clarified that **燬 (huǐ)** is the marquis’s *personal name*, and that he was posthumously **Duke Wen of Wei**. |
| `shuowen:7405` | Water transport translated as rotating a cart hub | Corrected to **transporting grain by water**, with source witness logged. |
| `shuowen:7663` | 借 in the transmitted source interpreted as borrowing a radical | English now describes the graph class as **containing** the component; Chinese source is not silently changed. |
| `shuowen:7891` | Gate bolt interpreted as “door-lifting strongman” | Corrected to **lifting a gate-bolt** following an attested variant. |
| `shuowen:7892` | Guoyu quotation unresolved as a name | Corrected to **Xi Zhi challenged Heaven**. |
| `shuowen:8436` | 椹質 misread as “very hard” | Corrected to **wooden target-blocks**. |
| `shuowen:8490` | Lelang statute wording left unintelligible | Explained as the **written form used for 織 (zhī)** in the Lelang statutes. |
| `shuowen:8874` | 蛇鮮 rendered as snakes and unidentified animals | Corrected to **snakes and eels** using Xunzi parallel. |
| `shuowen:9328` | 罰書 assumed to be a securely identified titled work | Changed to **“the text cited as 罰書”**; no silent change to the source title. |
| `shuowen:9489` | 孤 (gū) mistranslated “isolated minister” | Corrected to **senior dignitary**, an official rank. |
| `shuowen:7311, 8664` | Questions punctuated as exclamations | Corrected **question marks**. |

## 5. Proposals in the preliminary report that must NOT be adopted uncritically

| Key | Preliminary proposal / assumption | Cross-checked decision |
|:---|:---|:---|
| `shuowen:2326 and 2327` | “A five-/six-month-old lamb” must be “born in the fifth/sixth month.” | **Do not force this change.** Age vs calendar-month interpretation is not settled by the brief gloss alone; the [MOE dictionary](https://dict.revised.moe.edu.tw/dictView.jsp?ID=8009&q=1&word=%E7%BE%9C) supports the age reading for 羜 (zhù). The existing translation remains. |
| `shuowen:2333` | The change from 牡 (mǔ) to 牝 (pìn) is a definite OCR fix. | **Not an OCR certainty.** It is an attested Duan Yucai emendation differing from the received Da Xu source; apply only with an edition note. |
| `shuowen:974` | Restore corrupted 红 as 甲. | The compared witness instead has **𠦆**; the corrected file uses that reading. [CUHK](https://humanum.arts.cuhk.edu.hk/Lexis/lexi-mf/search.php?word=%E5%96%AE). |
| `shuowen:2118` | Restore headword as 𥄎. | The independent Shuowen witness has **䀘**. [Wikisource vol. 4](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/04). |
| `shuowen:2280` | East bird headword restored to 𪅿 or 鶅. | Independent edition actually has **甾** in this clause; use the compared witness, with original recorded. |
| `shuowen:2426` | Restore bird headword as 𪀘. | Independent witness has **鵖**; corrected accordingly. [Wikisource vol. 4](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97/04). |
| `shuowen:5525` | Restore headword as 𣤁. | **Incorrect:** the compared headword is **𣣳 (yáo)**. [MOE](https://dict.variants.moe.edu.tw/dictView.jsp?ID=89137). |
| `shuowen:7663` | Change 借 (jiè) to 皆 (jiē) as an unquestioned OCR correction. | **Do not silently overwrite.** 借 is attested in a transmitted version, whereas another witness has 皆. The revised English avoids the dubious semantic inference; Chinese preserves its current source reading. |
| `shuowen:8950` | Restore turtle graph as 𪛇. | **Incorrect:** the attested graph is **䶱 (tóng)**. [CText](https://ctext.org/shuo-wen-jie-zi/gui-bu2/zh). |
| `shuowen:9328` | Replace 罰書 directly with 周書. | **Do not silently overwrite.** 罰書 appears in the transmitted Shuowen entry. Its possible source affiliation should be explained in a note. |
| `shuowen:9588` | Correct gloss from 磊 (lěi) to 危 (wēi). | **Incorrect:** 磊 is supported by the compared Shuowen/Duan text, so the draft’s piled-stones sense is retained. [Duan at CText](https://ctext.org/wiki.pl?chapter=57589&if=gb). |
| `shuowen:6385` | Replace Duke Hui with “Marquis Hui.” | **Still wrong:** Hui is not the posthumous title. 燬 (huǐ) is the personal name; the figure is posthumously Duke **Wen** of Wei. |

## 6. Unresolved issues and next research priorities

**899 `[UNCERTAIN]` flags remain.** The present audit is not evidence that those passages have been resolved, and some unflagged entries may also contain errors. Prioritize by downstream impact and demonstrable source corruption, not by arbitrary key order.

| Priority | Scope | Recommended next action |
|:---|:---|:---|
| **P0 — source glyphs** | `shuowen:2220` (者), `shuowen:3558` (𣓁), `shuowen:6749` (𥲅) | Still include apparent corrupted characters `纺`, `纨`, and `钇` respectively. Compare against an authoritative edition and Duan before editing; do **not** substitute guessed rare code points. |
| **P1 — high-stakes glosses** | Ritual offices, ancient tax arrangements, title ranks, archaic measures, variant phonetic analyses, and citations of classical works | Inspect quotations in their full context; keep terminology and textual sources separate. |
| **P1 — historical geography** | Especially `shuowen:6202–9833`, water-related entries around `6948–7434` | Standardize naming where historically identifiable. Avoid assigning a modern location or pronunciation solely from the glyph without location-specific evidence. |
| **P2 — batch style drift** | Structural formula, alternative glosses, *chi/cun* versus modern English feet/inches, quotations | A subset was mechanically normalized. Remaining romanization, unit, and typographic variation requires a controlled second pass and QA. |
| **P2 — deep semantic validation** | Remaining 899 flags and non-flagged text alike | Review specialized botanical, zoological, ritual, carriage, and dialect definitions using Duan, Erya, Shijing, Zhouli, Guoyu, Zuozhuan and direct witnesses. |

**Why 899 remain:** A flag is retained whenever a difficult classical term, citation, botanical identity, philological uncertainty, or edition issue still needs independent confirmation. A correct spelling or normalized style does not itself establish interpretative certainty.

## 7. External comparison resources and their roles

| Source | Role | Limitation |
|:---|:---|:---|
| [Wikisource — Shuowen text](https://zh.wikisource.org/zh-hant/%E8%AA%AA%E6%96%87%E8%A7%A3%E5%AD%97) | Independent Chinese edition for graph and quotation checks | Transcriptions are not immune to variant readings or transcription errors. |
| [Chinese Text Project](https://ctext.org/shuo-wen-jie-zi) | Received text and comparison against ancient classical sources | Textual witnesses and historical period need careful identification. |
| [Duan Yucai — Shuowen Jiezi Zhu (CText)](https://ctext.org/wiki.pl?res=579380) | Text-critical interpretation and explicit alternative readings | Commentary is a scholarly emendation, not identical to Xu Shen’s received wording. |
| [Taiwan Ministry of Education — Dictionary of Chinese Character Variants](https://dict.variants.moe.edu.tw/) | Independent glyph identification and source attestation | A recorded character form may be a variant rather than the preferred normalized form. |
| [CUHK Chinese Character Database](https://humanum.arts.cuhk.edu.hk/Lexis/lexi-mf/) | Historical glyph forms and component cross-checks | Transcription reflects database editorial policy; verify witness differences. |
| [Shuowen.org](https://www.shuowen.org/) | Original entry lookup and comparison | Its input includes demonstrated corruption; do not treat as an infallible master copy. |
| [GitHub — shuowenjiezi/shuowen](https://github.com/shuowenjiezi/shuowen) | Machine-readable original-language comparison | Not an independently licensed complete English translation. |
| [Six Lines — Classical Chinese Dictionary](https://sixlines.day/en/chrome-dictionary) | Small independently translated English comparison set (93 entries reported) | Not full coverage and license must be checked before any text reuse. |
| [Wenlin](https://wenlin.co/) | Scholarly English historical lexicography, associated with Richard S. Cook research | A complete open/redistributable 9,833-entry translation has not been confirmed. |

### Suggested targeted cross-check of independent English material

If accessible and permitted, use the published Six Lines set to select **up to 93** matching keys, compare each meaning and graphic-analysis formula to our revised English, and record *disagreements*, not automatic replacements. Continue with Cook/Wenlin references where available. The cross-check performed for this handoff focuses on **Chinese witness readings, classical passages and independently verifiable terminology**; it is **not** a claim that all 9,833 meanings were compared against a second complete English translation.

## 8. Output artifacts, recommended ingestion and verification

| File | Purpose |
|:---|:---|
| `shuowen-english-corrected.txt` | 9,833-entry corrected working copy; consume for translations, with text-critical caveats. |
| `shuowen-translation-review-final.md` | This author-agent handoff and editorial protocol. |
| `shuowen-reviewed-entry-diff.csv` | Complete per-key original-vs-edited Chinese/English/uncertainty comparison. |
| `shuowen-source-restorations.csv` | 28 source edits, original and replacement strings, classifications and direct evidence URLs. |
| `shuowen-editorial-changes.jsonl` | Field-level source/English operations and reasons. |
| `shuowen-review-changes.jsonl` | Earlier substantive and mechanical English update operations. |
| `shuowen-english-review.txt` | Original supplied export, included for provenance and rollback. |
| `shuowen_jiezi_english_translation_review_report.md` | Original preliminary review, retained for comparison only; its proposals are not authoritative. |
| `shuowen-final-review-statistics.json` | Reproducible cardinality and checksum. |

**Agent integration checklist:**

- [ ] Confirm exactly 9,833 unique ordered keys in import and export.
- [ ] Carry over corrected English field; do not duplicate edits already applied.
- [ ] Retain original Chinese and optionally stage edited Chinese in a separate witness-aware field.
- [ ] Preserve 899 unresolved uncertainty flags.
- [ ] Provide an editorial note on all 6 source emendations, identifying original witness and preferred edited form.
- [ ] Keep source URLs as evidence metadata, not embedded in learner-facing character lessons.
- [ ] Re-run a glyph corruption scan on original Chinese for residual false substitutions and possible new hits.
- [ ] Only mark individual entries “fully verified” after case-by-case independent comparison.

**Validation:** A programmatic parse of the output confirmed consecutive keys `shuowen:1`–`shuowen:9833`; all changes are reconstructable by key against the included original/diff files. The corrected export SHA-256 is:

`4b9dfd6dc1082a0972f3689d5752c4a210b92c57b4d0f2fc07966e9ece9936e2`

---

**Bottom line for the author agent:** The requested concrete fixes have been made; this is not a report-only deliverable. Import the English corrections and use the source-restoration apparatus to control which Chinese readings enter the canonical corpus. Continue scholarly review of the 899 still-uncertain cases, prioritizing clear glyph corruptions and citations, rather than assuming global verification.
