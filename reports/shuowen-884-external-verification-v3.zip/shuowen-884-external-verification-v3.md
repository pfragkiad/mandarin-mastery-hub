# Shuowen Jiezi — External Verification of the 884 Remaining Uncertainties (v3)

**Date:** 22 November 2026  
**Input:** `shuowen-english-uncertainty-reviewed-v2.txt` and its 884 uncertain entries.  
**Output:** `shuowen-english-external-reviewed-v3.txt` (the full 9,833-entry master), `shuowen-remaining-uncertain-v3.txt`, `shuowen-884-reviewed-cases-v3.csv`, `shuowen-884-resolution-patch-v3.jsonl`.

## Verification scope and statistical result

| Metric | Count |
|---|---:|
| Originally still uncertain at start | 884 |
| Individually opened and read from public Shuowen repository this pass | 222 |
| Uncertainty flags removed, based on an independently examined interpretation | 109 |
| Translations revised with uncertainty retained | 91 |
| Individually checked but still unresolved, English unchanged | 22 |
| Not individually externally checked in this pass | 662 |
| English translations changed this pass | 166 |
| **Still uncertain after this pass** | **775** |
| Chinese strings modified in the master | **0** |

**Important:** An individually checked case means its actual individual entry, including the original Chinese and Duan Yucai’s commentary (where available), was retrieved and examined. This does **not** by itself guarantee an independently authored modern-Chinese translation was also accessible. The evidence URLs point to actual inspected entry-level GitHub records, and extra URLs to consulted independent dictionary/parallel textual evidence. Do not confuse a GitHub transcription of Duan with a separate critical edition.

Unreviewed cases are explicitly labeled, not relabeled as verified. This pass is **not** a full 884-entry scholarly clearance, and no unsupported claim of 884 verifications is made.

## Source policy

- Base Chinese and individual Duan-commentary records: [shuowenjiezi/shuowen](https://github.com/shuowenjiezi/shuowen), Apache-2.0 dataset. The upstream data has some known corruptions, so it is not a sole authority for disputed forms.
- Modern-Chinese dictionary checks for specific reviewed records: [Taiwan Ministry of Education](https://dict.variants.moe.edu.tw/), [Revised Mandarin Dictionary](https://dict.revised.moe.edu.tw/), and selected [Cídiǎnwǎng](https://www.cidianwang.com/shuowenjiezi/) pages.
- When Duan proposes an emendation, the *received Chinese string is preserved*, and the English notes the alternative reading rather than silently changing the transmitted text.
- **A corrected translation is not equivalent to modern paleographic validation** of Xu Shen’s character derivation.

## Applied changes and case-by-case evidence

The table below is exhaustive for the entries externally checked **during this pass**, not for all 884. The full 884-case register is in CSV. Entries marked `clear` have `[UNCERTAIN]` removed in the full master.

### `shuowen:34` — 祪 (guǐ) — `clear` (English revised)

**Chinese source:** 祔、祪，祖也。从示危聲。

**Decision:** Duan explicitly distinguishes 祔 as 新廟 and 祪 as 毀廟; corroborated by Guangyun.

**Final English:** An ancestor represented in a discontinued or dismantled ancestral temple (contrasted with 祔, associated with a new ancestral temple). Formed from 示, with 危 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/34.json), [Source 2](https://m.cidianwang.com/guangyun/gui/gui10098.htm)

### `shuowen:48` — 𥛽 (liù) — `clear` (English revised)

**Chinese source:** 祝𥛽也。从示畱聲。

**Decision:** Duan cites Suwen on curing illness by 祝由 and identifies 祝𥛽 with it; do not call it a generic invocation.

**Final English:** A ritual invocation used in healing, corresponding to 祝由. Formed from 示, with 畱 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/48.json), [Source 2](https://ctext.org/wiki.pl?chapter=548433&if=gb)

### `shuowen:88` — 璠 (fán) — `clear`

**Chinese source:** 璵璠。魯之寶玉。从玉番聲。孔子曰：“美哉璵璠。遠而望之，奐若也；近而視之，瑟若也。一則理勝，二則孚勝。”

**Decision:** Duan explicitly explains 奐 as patterned appearance, 瑟/璱 as jade sheen, 一 as the former and 二 as latter; original English adequate as a rendering, though quotation is transmitted in variant forms.

**Final English:** 璵璠, the precious jade of Lu. Formed from 玉, with 番 indicating the sound. Confucius said: “Beautiful is 璵璠! Seen from afar, it is radiant; viewed closely, it is lustrous. In one respect its texture excels; in another its luster excels.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/88.json), [Source 2](https://www.shuowen.org/view/88)

### `shuowen:141` — 瑮 (lì) — `checked_retained`

**Chinese source:** 玉英華羅列秩秩。从玉㮚聲。《逸論語》曰：“玉粲之璱兮。其𤩰猛也。”

**Decision:** Duan explains 秩秩 but does not clarify the obscure final quotation 𤩰猛; retain uncertainty.

**Final English:** Jade's brilliance arrayed in orderly ranks. Formed from 玉, with 㮚 indicating the sound. The Lost Analects says: “The jade glitters lustrously; its 𤩰 is vigorous.” [The final description is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/141.json)

### `shuowen:195` — 玟 (méi) — `revised_retained` (English revised)

**Chinese source:** 火齊，玫瑰也。一曰石之美者。从玉文聲。

**Decision:** Duan associates 火齊 with a layered mica-like mineral and describes 玟瑰 among precious stones; avoid unqualified equivalence.

**Final English:** A precious red or yellow-red mineral material associated with 火齊 and 玫瑰. Another explanation: a fine stone. Formed from 玉, with 文 indicating the sound. [The precise identification and relationship of these historical mineral terms remain uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/195.json), [Source 2](https://dict.variants.moe.edu.tw/dictView.jsp?ID=27583)

### `shuowen:204` — 𤪎 (yǒu) — `clear` (English revised)

**Chinese source:** 遺玉也。从玉𣣸聲。

**Decision:** Duan explicitly: 謂贈遺之玉也, and cites funeral jade offerings.

**Final English:** Jade presented as a funerary gift to the dead. Formed from 玉, with 𣣸 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/204.json), [Source 2](https://www.shuowen.org/view/204?bushou=%E7%8E%89)

### `shuowen:226` — 士 (shì) — `clear` (English revised)

**Chinese source:** 事也。數始於一，終於十。从一从十。孔子曰：“推十合一爲士。”凡士之屬皆从士。

**Decision:** Duan explains 士 via 事 and 任事 and interprets the numerical unity as synthesizing broad learning.

**Final English:** A person entrusted with affairs or duties. Numbers begin at one and end at ten. Formed from 一 and 十. Confucius is quoted as saying: “To bring ten together under one is to make 士.” All characters in the 士 category are formed from 士.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/226.json), [Source 2](https://www.shuowen.org/view/226)

### `shuowen:236` — 毒 (dú) — `revised_retained` (English revised)

**Chinese source:** 厚也。害人之艸，往往而生。从屮从毒。

**Decision:** Duan explicitly analyzes 屮 plus 毒聲 and explains 厚 in either positive or negative sense; cannot silently rewrite the Chinese source.

**Final English:** Abundance or intensity; the text links the meaning to harmful plants growing prolifically. The received graphic formula says “formed from 屮 and 毒”; Duan instead analyzes 屮 as the plant component and 毒 as the phonetic. [Received graphical formula is self-referential and disputed.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/236.json), [Source 2](https://www.shuowen.org/view/236)

### `shuowen:361` — 藄 (qí) — `revised_retained` (English revised)

**Chinese source:** 綦月爾也。从艸綦聲。

**Decision:** MOE cites Erya and Guo Pu, identifying the plant 紫藄, like edible ferns. Duan’s 士夫 emendation conflicts with Da Xu.

**Final English:** An edible fern-like plant called 紫藄 or 月爾, identified in a traditional commentary as a purple fern. Formed from 艸, with 綦 indicating the sound. [Duan proposes a substantially different ancient gloss 士夫也; the received text is disputed.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/361.json), [Source 2](https://dict.variants.moe.edu.tw/dictView.jsp?ID=69368)

### `shuowen:367` — 藑 (qióng) — `revised_retained` (English revised)

**Chinese source:** 茅，葍也。一名蕣。从艸夐聲。

**Decision:** Duan restores omitted 藑 and questions 一名蕣, cross-referencing Erya. Botanic identification remains uncertain.

**Final English:** A grass-like plant identified as 藑茅, belonging to the 葍 group. Formed from 艸, with 夐 indicating the sound. [The received alternative name 蕣 is challenged by Duan Yucai.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/367.json), [Source 2](https://www.shuowen.org/view/367)

### `shuowen:405` — 芐 (hù) — `revised_retained` (English revised)

**Chinese source:** 地黃也。从艸下聲。《禮記》“鈃毛：牛、藿；羊、芐；豕、薇。”是。

**Decision:** Duan identifies the medicinal plant 地黃 (乾地黃) but notes ritual-text variants 芐/苦 and a debate with Zheng Xuan.

**Final English:** The medicinal plant called 地黃 (rehmannia). Formed from 艸, with 下 indicating the sound. The cited ritual food text specifies different herbs served with beef, mutton and pork. [Classical witnesses differ over the precise mutton-herb reading.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/405.json)

### `shuowen:515` — 蔕 (dì) — `clear` (English revised)

**Chinese source:** 瓜當也。从艸帶聲。

**Decision:** Duan cites fruit 鼻 and 瓜當; confirms pedicel/fruit attachment.

**Final English:** The stalk or attachment at the base of a melon or other fruit (its pedicel). Formed from 艸, with 帶 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/515.json)

### `shuowen:538` — 芼 (mào) — `clear` (English revised)

**Chinese source:** 艸覆蔓。从艸毛聲。《詩》曰：“左右芼之。”

**Decision:** Duan distinguishes original ground-cover sense from Shijing plant-selection and culinary uses.

**Final English:** Plants spreading across and covering the ground. Formed from 艸, with 毛 indicating the sound. The Odes says: “Gather and select it to left and right.” [The quotation uses the derived sense of selecting edible plants.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/538.json), [Source 2](https://www.shuowen.org/view/538)

### `shuowen:555` — 菸 (yū) — `revised_retained` (English revised)

**Chinese source:** 鬱也。从艸於聲。一曰𣨙也。

**Decision:** Duan explicitly treats 鬱 as a corrupt reading and explains damage to plants by excess wetness or drying.

**Final English:** To wilt, become limp or withered. Formed from 艸, with 於 indicating the sound. Another explanation describes a sickly or languishing condition. [Duan argues that 鬱 in the received text should instead be 𩰪.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/555.json), [Source 2](https://www.shuowen.org/view/555?pinyin=yu)

### `shuowen:568` — 䒹 (lèi) — `clear` (English revised)

**Chinese source:** 耕多艸。从艸、耒，耒亦聲。

**Decision:** Duan identifies a semantic combination of plow and vegetation; no residual semantic ambiguity.

**Final English:** To plow land thickly overgrown with grass. Formed from 艸 and 耒; 耒 also indicates the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/568.json), [Source 2](https://www.shuowen.org/view/568)

### `shuowen:570` — 蔪 (jiàn) — `clear` (English revised)

**Chinese source:** 艸相蔪苞也。从艸斬聲。《書》曰：“艸木蔪苞。”

**Decision:** Duan explains 蔪苞 as vegetation growing intertwined in clusters; MOE confirms 蔪苞. Duan treats the Documents quotation as perhaps added later.

**Final English:** Dense plants growing together in intertwining clumps. Formed from 艸, with 斬 indicating the sound. The Documents describes grasses and trees becoming densely intertwined.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/570.json), [Source 2](https://dict.revised.moe.edu.tw/dictView.jsp?ID=5832&q=1&word=4)

### `shuowen:592` — 荃 (quán) — `revised_retained`

**Chinese source:** 芥脃也。从艸全聲。

**Decision:** Duan explains 芥脃 as a palatable finely minced mustard-green preparation 芥韲; the existing English expresses the preparation accurately.

**Final English:** A crisp mustard-green preparation; Duan Yucai relates it to finely chopped mustard greens (芥荃). Formed from 艸, with 全 indicating the sound. [Exact preparation uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/592.json)

### `shuowen:593` — 䔯 (kù) — `checked_retained`

**Chinese source:** 韭鬱也。从艸酤聲。

**Decision:** Duan links 韭鬱 to prepared or preserved chives, but the exact process/type of food is insufficiently established.

**Final English:** Preserved chives. Formed from 艸, with 酤 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/593.json)

### `shuowen:597` — 𧆈 (yì) — `revised_retained` (English revised)

**Chinese source:** 煎茱萸。从艸𩕺聲。漢津：會稽獻𧆈一斗。

**Decision:** Duan compares ritual culinary sources; 𧆈 corresponds to 藙. The text varies between Han jin and Han lü.

**Final English:** A seasoning or food preparation made by cooking 茱萸, the aromatic fruit of edible prickly ash. Formed from 艸, with 𩕺 indicating the sound. The text records a Han-era requirement for Kuaiji to present one dou of it. [The received attribution 漢津 is likely corrupt for 漢律.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/597.json), [Source 2](https://dict.variants.moe.edu.tw/dictView.jsp?ID=69420)

### `shuowen:601` — 𦭮 (zhì) — `checked_retained`

**Chinese source:** 以艸補缺。从艸㐁聲。讀若陸。或以爲綴。一曰約空也。

**Decision:** Duan notes the phrase 約空 has no established interpretation and questions 讀若陸; whole entry remains genuinely unclear.

**Final English:** To fill a gap with plants. Formed from 艸, with 㐁 indicating the sound. Read like 陸. Some take it as 綴, to join; another explanation: to bind across an opening.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/601.json)

### `shuowen:704` — 小 (xiǎo) — `clear`

**Chinese source:** 物之微也。从八，丨見而分之。凡小之屬皆从小。

**Decision:** Duan explains 八 as division and 丨 as a very short emerging stroke; the existing translation is faithful.

**Final English:** The minuteness of things. Formed from 八, with 丨 appearing and dividing it. All characters in the 小 category are formed from 小.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/704.json)

### `shuowen:717` — 必 (bì) — `clear` (English revised)

**Chinese source:** 分極也。从八、弋，弋亦聲。

**Decision:** Duan interprets 分極 as setting a marker/standard (立表爲分判之準) rather than “dividing to the utmost.”

**Final English:** A dividing standard or boundary marker. Formed from 八 and 弋, with 弋 also indicating the sound; by extension, “necessary” or “certain.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/717.json)

### `shuowen:727` — 牛 (niú) — `revised_retained` (English revised)

**Chinese source:** 大牲也。牛，件也；件，事理也。象角頭三、封㞑之形。凡牛之屬皆从牛。

**Decision:** Duan challenges the received 大牲也、件也 passage; do not treat this as an established paleographic derivation.

**Final English:** Cattle, a major animal for sacrifice and agricultural work. The text offers an early interpretive association with 件, or the ordering of affairs, and describes a form depicting horns, head and body. All characters in the 牛 category are formed from 牛. [Duan argues that some transmitted explanatory wording is a later interpolation.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/727.json)

### `shuowen:776` — 斄 (lái) — `clear`

**Chinese source:** 彊曲毛，可以箸起衣。从犛省，來聲。

**Decision:** Duan identifies stiff curled hair used as garment stuffing; existing English accurate.

**Final English:** Stiff, curled hair usable as padding to raise clothing. Formed from abbreviated 犛, with 來 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/776.json)

### `shuowen:786` — 噲 (kuài) — `revised_retained` (English revised)

**Chinese source:** 咽也。从口會聲。讀若快。一曰嚵，噲也。

**Decision:** Duan understands 噲 as 声气所会; questions the received 嚵噲 wording.

**Final English:** The throat, where breath and voice converge. Formed from 口, with 會 indicating the sound. Read like 快. Another explanation relates it to voracious or greedy eating. [The transmitted wording of the alternative gloss differs between editions.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/786.json)

### `shuowen:803` — 啜 (chuò) — `clear`

**Chinese source:** 嘗也。从口叕聲。一曰喙也。

**Decision:** Source and Duan support the taste/sip sense and the separate mouth/beak alternative.

**Final English:** To taste. Formed from 口, with 叕 indicating the sound. Another explanation: a mouth or beak.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/803.json)

### `shuowen:809` — 嚵 (chán) — `checked_retained`

**Chinese source:** 小𠻜也。从口毚聲。一曰喙也。

**Decision:** The primary gloss 小𠻜 is obscure, and Duan does not explain it. Do not claim a verified translation of “to sip a little.”

**Final English:** To sip a little. Formed from 口, with 毚 indicating the sound. Another explanation: a mouth or beak.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/809.json)

### `shuowen:810` — 噬 (shì) — `clear`

**Chinese source:** 啗也。喙也。从口筮聲。

**Decision:** Eating/biting and a mouth or beak are explicit in the historical gloss; no further ambiguity in English.

**Final English:** To eat; a mouth or beak. Formed from 口, with 筮 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/810.json)

### `shuowen:817` — 嚛 (hù) — `clear` (English revised)

**Chinese source:** 食辛嚛也。从口樂聲。

**Decision:** Duan equates 嚛 with biting pungency 辛螫 and compares 辛而不烈.

**Final English:** A harsh, biting or burning sensation from eating something pungent. Formed from 口, with 樂 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/817.json)

### `shuowen:823` — 呬 (xì) — `revised_retained` (English revised)

**Chinese source:** 東夷謂息爲呬。从口四聲。《詩》曰：“犬夷呬矣。”

**Decision:** Duan explicitly says 東夷當作東齊 and compares three Odes readings. Avoid taking 犬夷/呬 as an uncontested literal quote.

**Final English:** To breathe or rest, called 呬 in a regional eastern dialect. Formed from 口, with 四 indicating the sound. The cited Odes line uses an alternative written tradition. [Duan argues that 東夷 should read 東齊 and that the transmitted Odes characters differ.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/823.json)

### `shuowen:830` — 啍 (tūn) — `clear` (English revised)

**Chinese source:** 口气也。从口𦎫聲。《詩》曰：“大車啍啍。”

**Decision:** Duan quotes Mao: 啍啍, 重遟之貌 and explains the development from slow breathing.

**Final English:** Breath issuing from the mouth. Formed from 口, with 𦎫 indicating the sound. The Odes describes a great cart moving heavily and slowly, extending the sense to slow, labored movement.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/830.json)

### `shuowen:832` — 𡂒 (zhì) — `clear` (English revised)

**Chinese source:** 野人言之。从口質聲。

**Decision:** Duan invokes the Analects 質勝文則野, confirming rustic/uncultivated usage.

**Final English:** Speech characteristic of an uncultivated or rustic person. Formed from 口, with 質 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/832.json)

### `shuowen:852` — 𡂢 (jiāo) — `revised_retained` (English revised)

**Chinese source:** 聲𡂢𡂢也。从口䲷聲。

**Decision:** Duan cites Zhouli invocations, shouting to divine beings in disaster; also suspects graphic corruption in the transmitted headword.

**Final English:** A repeated loud calling or shouted invocation, written 𡂢𡂢. Formed from 口, with 䲷 indicating the sound. [The exact historical phonetic form and transmitted graph are disputed.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/852.json)

### `shuowen:894` — 𠱫 (è) — `clear`

**Chinese source:** 語相訶歫也。从口歫䇂。䇂，惡聲也。讀若櫱。

**Decision:** Duan directly defines 訶歫 as rebuking and refusing; existing translation adequately captures it.

**Final English:** Speech in mutual rebuke and resistance. Formed from 口 opposed to 䇂; 䇂 is an unpleasant sound. Read like 櫱.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/894.json)

### `shuowen:901` — 嗙 (bēng) — `checked_retained`

**Chinese source:** 謌聲。嗙喻也。从口㫄聲。司馬相如說，淮南宋蔡舞嗙喻也。

**Decision:** Duan establishes a song/dance context but does not conclusively clarify the specific performance term 嗙喻.

**Final English:** A singing sound, 嗙喻. Formed from 口, with 㫄 indicating the sound. Sima Xiangru explains it as the 嗙喻 accompaniment to dances of Huainan, Song and Cai.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/901.json)

### `shuowen:926` — 嘆 (tàn) — `clear`

**Chinese source:** 吞歎也。从口，歎省聲。一曰太息也。

**Decision:** Duan specifically distinguishes a stifled/unsounded sigh from a simple great sigh; existing translation retains both alternatives.

**Final English:** To sigh with swallowed breath. Formed from 口, with abbreviated 歎 indicating the sound. Another explanation: a deep sigh.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/926.json)

### `shuowen:928` — 哨 (shào) — `clear` (English revised)

**Chinese source:** 不容也。从口肖聲。

**Decision:** Duan references small/narrow vessel openings in ancient contexts; the original gloss 不容 is retained.

**Final English:** Narrow or insufficiently capacious; unable to contain something. Formed from 口, with 肖 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/928.json)

### `shuowen:939` — 𠴫 (jì) — `clear`

**Chinese source:** 嗼也。从口叔聲。

**Decision:** Duan supports silent/still meaning via 寂; existing English adequate.

**Final English:** The state 嗼, silence. Formed from 口, with 叔 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/939.json)

### `shuowen:940` — 嗼 (mò) — `clear`

**Chinese source:** 𠴫嗼也。从口莫聲。

**Decision:** Duan cites Erya 嗼、定也 and Lüshi Chunqiu 嗼然無聲, confirming silence.

**Final English:** 𠴫嗼, a state of silence. Formed from 口, with 莫 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/940.json)

### `shuowen:955` — 噳 (yǔ) — `clear` (English revised)

**Chinese source:** 麋鹿羣口相聚皃。从口虞聲。《詩》曰：“麀鹿噳噳。”

**Decision:** Duan cites Mao 噳噳然衆也; original “gathering their mouths together” is misleading literalism.

**Final English:** A crowded herd of deer, gathered closely together. Formed from 口, with 虞 indicating the sound. The Odes says: “The deer gather in a throng.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/955.json)

### `shuowen:958` — 㕣 (yǎn) — `clear`

**Chinese source:** 山閒陷泥地。从口，从水敗皃。讀若沇州之沇。九州之渥地也，故以沇名焉。

**Decision:** Both MOE and Duan confirm muddy waterlogged low ground between mountains. Graphical theory remains historical attribution.

**Final English:** Sunken muddy ground between mountains. Formed from 口 and the appearance of water breaking down the ground. Read like 沇 in Yanzhou. This is the wet land of the nine provinces, hence named 沇.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/958.json), [Source 2](https://dict.variants.moe.edu.tw/dictView.jsp?ID=80369)

### `shuowen:971` — 𤕦 (níng) — `checked_retained`

**Chinese source:** 亂也。从爻、工、交、吅。一曰窒𤕦。讀若禳。

**Decision:** Duan says 疑有譌脫; 𤕦 is an uncertain explanation with an obscure alternative usage. No flag cleared.

**Final English:** Disorder. Formed from 爻, 工, 交 and 吅. Another explanation: obstruction, 窒𤕦. Read like 禳.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/971.json)

### `shuowen:974` — 單 (dān) — `revised_retained` (English revised)

**Chinese source:** 大也。从吅、𠦆，吅亦聲。闕。

**Decision:** Duan proposes 大言也 for the received 大也; keep any restored component independently documented.

**Final English:** Great or loud, perhaps originally referring to loud speech. Formed from 吅 and 𠦆, with 吅 also indicating the sound; the remaining graphical explanation is missing. [Duan proposes that the received gloss 大也 omitted 言, but the Chinese working text preserves it.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/974.json)

### `shuowen:990` — 趁 (chèn) — `revised_retained` (English revised)

**Chinese source:** 𧾍也。从走㐱聲。讀若塵。

**Decision:** Duan connects 趁𧾍 to a difficult, impeded movement described in Yijing. Source 𧾍 cross-reference remains elliptic.

**Final English:** A manner of moving with difficulty or making slow progress (in a paired expression with 𧾍). Formed from 走, with 㐱 indicating the sound. Read like 塵. [Duan rejects the later common sense “to pursue” as a gloss of the original usage.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/990.json)

### `shuowen:991` — 𧾍 (zhān) — `revised_retained` (English revised)

**Chinese source:** 趁也。从走亶聲。

**Decision:** Duan cites the difficulty of proceeding in Yijing 屯, not modern “to pursue.”

**Final English:** A manner of moving with difficulty or making slow progress, paired with 趁. Formed from 走, with 亶 indicating the sound. [Duan argues the two entries originally formed a compound expression.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/991.json)

### `shuowen:992` — 趞 (què) — `checked_retained`

**Chinese source:** 趞趞也。一曰行皃。从走昔聲。

**Decision:** Primary reduplicated phrase 趞趞 remains unexplained even in Duan; alternative “a manner of walking” is generic.

**Final English:** The manner 趞趞. Another explanation: a manner of walking. Formed from 走, with 昔 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/992.json)

### `shuowen:1012` — 䞗 (cāi) — `clear`

**Chinese source:** 疑之，等䞗而去也。从走才聲。

**Decision:** Duan explicitly explains the indecisive delayed movement before leaving; existing English faithful.

**Final English:** Doubting and hesitating before departing. Formed from 走, with 才 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1012.json)

### `shuowen:1029` — 趙 (zhào) — `clear` (English revised)

**Chinese source:** 趨趙也。从走肖聲。

**Decision:** Previous checked entry 1028 and Duan support slow progress. Cross-reference no longer left untranslated.

**Final English:** To walk slowly or linger, as in the old expression 趨趙. Formed from 走, with 肖 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1029.json)

### `shuowen:1033` — 䟑 (yuè) — `checked_retained`

**Chinese source:** 趠䟑也。从走龠聲。

**Decision:** Duan and Guangyun only say the repeated expression describes a way of moving; precise action remains obscure.

**Final English:** A far-reaching manner of movement, 趠䟑. Formed from 走, with 龠 indicating the sound. [The precise gait is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1033.json)

### `shuowen:1035` — 𧼪 (chì) — `clear`

**Chinese source:** 超特也。从走契聲。

**Decision:** Duan cross-references 跇 as an extraordinary leap across obstacles; existing English is adequate.

**Final English:** To leap exceptionally far or high. Formed from 走, with 契 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1035.json)

### `shuowen:1047` — 䞭 (qūn) — `clear` (English revised)

**Chinese source:** 行趚䞭也。从走夋聲。

**Decision:** Duan cites source showing 行速 and 广雅 䞭犇也. Previously uninformative English upgraded.

**Final English:** To move or run rapidly, especially in the reduplicated expression 䞭䞭. Formed from 走, with 夋 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1047.json)

### `shuowen:1052` — 䞣 (chě) — `revised_retained` (English revised)

**Chinese source:** 距也。从走，㡿省聲。《漢令》曰：“䞣張百人。”

**Decision:** Duan analyzes 蹶張 as treading down to draw strong crossbows with the feet, contradicting generic “resist”.

**Final English:** To brace or tread forcefully, particularly in the Han military expression for drawing a strong crossbow with the feet. Formed from 走, with an abbreviated 㡿 indicating the sound. A Han ordinance mentions a hundred crossbow-drawers. [Duan discusses conflicting readings 䞣張 and 蹶張 and competing glyph analyses.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1052.json)

### `shuowen:1055` — 𧻚 (yuán) — `clear` (English revised)

**Chinese source:** 𧻚田，易居也。从走亘聲。

**Decision:** Duan cites Zhouli and Hanshu at length explaining periodic plot reassignment and agricultural rotation.

**Final English:** To rotate or exchange cultivated plots and the associated place of residence under an ancient system of reallocating farmland. Formed from 走, with 亘 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1055.json)

### `shuowen:1057` — 𧻹 (yǒng) — `clear` (English revised)

**Chinese source:** 喪辟𧻹。从走甬聲。

**Decision:** Duan explains 擗 as chest-beating and 𧻹 as ritual leaping; contrasts written 踊.

**Final English:** To stamp or leap in a mourning rite, often in the expression 擗踊. Formed from 走, with 甬 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1057.json)

### `shuowen:1065` — 𣥺 (chēng) — `clear` (English revised)

**Chinese source:** 歫也。从止尚聲。

**Decision:** Duan traces the term to supporting/holding off, later written 撐.

**Final English:** To brace, prop up, or resist. Formed from 止, with 尚 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1065.json)

### `shuowen:1066` — 歭 (chí) — `clear`

**Chinese source:** 䠧也。从止寺聲。

**Decision:** Duan cites 踟躕 and 歭䠧 as hesitating or not advancing, validating existing gloss.

**Final English:** To hesitate, 䠧. Formed from 止, with 寺 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1066.json)

### `shuowen:1083` — 啙 (zǐ) — `checked_retained`

**Chinese source:** 窳也。闕。

**Decision:** Duan explicitly suspects the entry was added by later editors; do not treat the received text as secure.

**Final English:** Weak or defective. The explanation is missing.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1083.json)

### `shuowen:1090` — 尟 (xiǎn) — `clear` (English revised)

**Chinese source:** 是少也。尟俱存也。从是、少。賈侍中說。

**Decision:** Duan corrects received 尟俱存也 as a corruption of 是俱存也: one item alone is lacking.

**Final English:** Lacking this particular thing; “it is this that is few or absent,” although other things remain present. Formed from 是 and 少. This explanation is attributed to Palace Attendant Jia.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1090.json)

### `shuowen:1099` — 邎 (yóu) — `revised_retained` (English revised)

**Chinese source:** 行邎徑也。从辵䌛聲。

**Decision:** Duan suggests an original path-taking sense, not “a circuitous path.”

**Final English:** To travel along a path or shortcut. Formed from 辵, with 䌛 indicating the sound. [Duan questions the received wording 行邎徑 and favors 行徑 or 行由徑.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1099.json)

### `shuowen:1100` — 𨒌 (zhēng) — `clear`

**Chinese source:** 正、行也。从辵正聲。

**Decision:** Duan distinguishes 征 as proper going forth, in contrast with other types of travel; existing translation adequate.

**Final English:** To proceed correctly. Formed from 辵, with 正 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1100.json)

### `shuowen:1115` — 遝 (tà) — `clear` (English revised)

**Chinese source:** 䢔也。从辵眔聲。

**Decision:** Duan cites 方言 遝、及也 and 广韵 遝行相及也; fixes vague “come together.”

**Final English:** To reach, overtake or catch up with someone or something. Formed from 辵, with 眔 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1115.json)

### `shuowen:1116` — 䢔 (hé) — `clear` (English revised)

**Chinese source:** 遝也。从辵合聲。

**Decision:** Duan cross-ref and 广韵 define 遝行相及, supporting overtaking rather than merely meeting.

**Final English:** To reach or catch up with, the same as 遝. Formed from 辵, with 合 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1116.json)

### `shuowen:1118` — 逪 (cuò) — `revised_retained` (English revised)

**Chinese source:** 迹逪也。从辵昔聲。

**Decision:** Duan cites ritual movement 交錯, where participants proceed in alternating crossing directions.

**Final English:** To cross or move obliquely, especially in alternating or intersecting paths. Formed from 辵, with 昔 indicating the sound. [Duan argues that the received 迹逪 should instead read 䢒逪.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1118.json)

### `shuowen:1145` — 邐 (lǐ) — `revised_retained`

**Chinese source:** 行邐邐也。从辵麗聲。

**Decision:** Duan explains 邐邐 as twisting or winding, supporting current translation.

**Final English:** To walk in a winding or continuous course, described as 邐邐. Formed from 辵, with 麗 indicating the sound. [The precise descriptive sense is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1145.json)

### `shuowen:1146` — 逮 (dài) — `clear`

**Chinese source:** 唐逮，及也。从辵隶聲。

**Decision:** Duan explains 唐逮 as old paired expression for “reach”; existing English faithful.

**Final English:** 唐逮: to reach. Formed from 辵, with 隶 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1146.json)

### `shuowen:1167` — 連 (lián) — `revised_retained` (English revised)

**Chinese source:** 員連也。从辵从車。

**Decision:** Major error in draft: Duan restores 負車 and explains original carriage/palanquin use, with continuity as a semantic extension.

**Final English:** Originally, a carriage drawn or pulled along by a person, related to the old form of 輦; later, things joined in an unbroken sequence. Formed from 辵 and 車. [Duan argues the transmitted gloss 員連 is corrupt for 負車.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1167.json)

### `shuowen:1169` — 䢙 (bài) — `clear`

**Chinese source:** 𣀩也。从辵貝聲。《周書》曰：“我興受其䢙。”

**Decision:** Duan explicitly equates with 敗: to ruin or destroy; original English is accurate.

**Final English:** To defeat or ruin, 𣀩. Formed from 辵, with 貝 indicating the sound. The Book of Zhou says: “We rise to receive its defeat.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1169.json)

### `shuowen:1174` — 遂 (suì) — `clear`

**Chinese source:** 亾也。从辵㒸聲。

**Decision:** Duan says later meanings “achieve / proceed” derived from earlier vanish/go away, supporting historical gloss.

**Final English:** To perish or go away. Formed from 辵, with 㒸 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1174.json)

### `shuowen:1180` — 邋 (liè) — `revised_retained` (English revised)

**Chinese source:** 搚也。从辵巤聲。

**Decision:** Duan relates 搚 to 拹, “fold” or “press together”; old “draw together” acceptable but vague.

**Final English:** To compress, fold or draw together. Formed from 辵, with 巤 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1180.json)

### `shuowen:1191` — 遱 (lóu) — `clear` (English revised)

**Chinese source:** 連遱也。从辵婁聲。

**Decision:** Duan cites 集韵 连遱谓不绝貌, fully resolving compound.

**Final English:** To continue or move in an unbroken succession. Formed from 辵, with 婁 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1191.json)

### `shuowen:1192` — 䢌 (zhì) — `revised_retained` (English revised)

**Chinese source:** 前頡也。从辵巿聲。賈侍中說：一讀若㭘，又若郅。

**Decision:** Duan notes variant glyph and interpretation; preserve uncertainty, avoid confident body posture.

**Final English:** To move forward with the face or head thrust out, as in a particular way of running or moving. Formed from 辵, with 巿 indicating the sound. Palace Attendant Jia offers readings like 㭘 or 郅. [Duan discusses a competing graph and the gloss 䢡走也.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1192.json)

### `shuowen:1202` — 𨔥 (jiān) — `clear` (English revised)

**Chinese source:** 目進極也。从辵𦘔聲。

**Decision:** Duan explains 進 and 至; existing phrase “advance eyes” is misleading literalism.

**Final English:** To advance or arrive at the furthest point. Formed from 辵, with 𦘔 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1202.json)

### `shuowen:1230` — 彼 (bǐ) — `checked_retained`

**Chinese source:** 往，有所加也。从彳皮聲。

**Decision:** Duan provides little explanation beyond a rhyme gloss; the puzzling 往有所加 cannot be securely translated as “go with something added.”

**Final English:** To go, with something added. Formed from 彳, with 皮 indicating the sound. [The gloss is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1230.json)

### `shuowen:1245` — 㣙 (dí) — `revised_retained` (English revised)

**Chinese source:** 行㣙㣙也。从彳由聲。

**Decision:** Duan offers 行平易也, but marked with 葢 (probably); retain uncertainty.

**Final English:** To walk calmly or on level ground, in the repeated expression 㣙㣙. Formed from 彳, with 由 indicating the sound. [Duan identifies this as an interpretation of an obscure reduplicated form.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1245.json)

### `shuowen:1254` — 徛 (jì) — `clear` (English revised)

**Chinese source:** 舉脛有渡也。从彳奇聲。

**Decision:** Duan cites Erya 石杠謂之徛, describing stepping-stones placed in water.

**Final English:** To cross water on a line of stepping-stones, lifting one’s legs to step over. Formed from 彳, with 奇 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1254.json)

### `shuowen:1255` — 𢓈 (xùn) — `clear` (English revised)

**Chinese source:** 行示也。从彳勻聲。《司馬法》：“斬以𢓈。”

**Decision:** Duan quotes Zhouli describing a sacrificial or execution display made around the army.

**Final English:** To make a circuit of a military formation displaying or proclaiming an execution or order. Formed from 彳, with 勻 indicating the sound. The Methods of Sima says: “Execute and display it to the troops.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1255.json)

### `shuowen:1281` — 齜 (chái) — `revised_retained` (English revised)

**Chinese source:** 齒相齗也。一曰開口見齒之皃。从齒，柴省聲。讀若柴。

**Decision:** Duan corrects 齗 to 齘, and calls it irregular teeth; clear bared-teeth sense but source conflict.

**Final English:** Teeth that are uneven or set against one another; another explanation is the appearance of bared teeth. Formed from 齒, with an abbreviated 柴 indicating the sound. Read like 柴. [Duan proposes 齘 in place of transmitted 齗.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1281.json)

### `shuowen:1285` — 齺 (zōu) — `revised_retained` (English revised)

**Chinese source:** 齒搚也。一曰齰也。一曰馬口中糜也。从齒芻聲。

**Decision:** Duan explains 齒搚 as folding/crowding, and associates horse-mouth interpretation with a hard bit element, not chewed mash.

**Final English:** Teeth pressed or crowded together, or biting. Another explanation concerns a hard object in a horse’s mouth. Formed from 齒, with 芻 indicating the sound. [The transmitted clause 馬口中糜 is disputed.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1285.json)

### `shuowen:1307` — 䶣 (ái) — `clear` (English revised)

**Chinese source:** 𪙌牙也。从齒豈聲。

**Decision:** Duan interprets 𪙌牙 as 差齒, uneven teeth, rather than “grinding teeth.”

**Final English:** Unevenly arranged or projecting teeth. Formed from 齒, with 豈 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1307.json)

### `shuowen:1322` — 牙 (yá) — `revised_retained` (English revised)

**Chinese source:** 牡齒也。象上下相錯之形。凡牙之屬皆从牙。

**Decision:** Duan explicitly explains difference between front 齒 and back 牙 and corrects 牡 to 壯; received Chinese remains unchanged.

**Final English:** Large back teeth (molars). The graph is said to depict upper and lower teeth interlocking. All characters in the 牙 category are formed from 牙. [Duan argues that received 牡齒 is a corruption of 壯齒, “large/strong teeth,” not a reference to male teeth.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1322.json)

### `shuowen:1323` — 𤘌 (qī) — `revised_retained` (English revised)

**Chinese source:** 武牙也。从牙从奇，奇亦聲。

**Decision:** Duan calls it tiger tooth and cites older sources. Retain flag for textual variant 武/虎.

**Final English:** A projecting canine tooth, or a fang conspicuously standing out. Formed from 牙 and 奇; 奇 also indicates the sound. [Duan argues received 武牙 originally read 虎牙.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1323.json)

### `shuowen:1335` — 踖 (jí) — `clear`

**Chinese source:** 長脛行也。从足㫺聲。一曰踧踖。

**Decision:** Duan identifies both long-stepped walking and the alternate sense “walking cautiously/reverently” in 踧踖.

**Final English:** To walk with long shins or extended legs. Formed from 足, with 㫺 indicating the sound. Another explanation: the cautious gait 踧踖.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1335.json)

### `shuowen:1348` — 跧 (zhuān) — `clear`

**Chinese source:** 蹴也。一曰卑也，絭也。从足全聲。

**Decision:** Duan explains squatting/folding the body from 絭 = 拳曲, supporting existing English.

**Final English:** To kick or tread. Another explanation: to crouch low and curl up. Formed from 足, with 全 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1348.json)

### `shuowen:1361` — 踶 (dì) — `clear` (English revised)

**Chinese source:** 躛也。从足是聲。

**Decision:** Duan cites 小蹋謂之踶; current “to guard” is unsupported.

**Final English:** To stamp or tread with the foot; to give a small kick. Formed from 足, with 是 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1361.json)

### `shuowen:1363` — 䠟 (dié) — `clear` (English revised)

**Chinese source:** 䠟足也。从足執聲。

**Decision:** Duan explicitly equates 䠟 with 蹀 and cites ancient expression 喋血. Replaces vague “feet drawn together”.

**Final English:** To tread or step, especially in the historical expression for wading through blood that stains the feet. Formed from 足, with 執 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1363.json)

### `shuowen:1367` — 踤 (zú) — `clear`

**Chinese source:** 觸也。从足卒聲。一曰駭也。一曰蒼踤。

**Decision:** Duan explains contact/stamping and panic/haste meaning 蒼踤; existing draft includes both.

**Final English:** To strike against. Formed from 足, with 卒 indicating the sound. Another explanation: to startle; another: the expression 蒼踤. [The final expression is unexplained.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1367.json)

### `shuowen:1377` — 䟺 (bèi) — `clear` (English revised)

**Chinese source:** 步行獵跋也。从足貝聲。

**Decision:** Duan defines 獵跋 as 踐踏, not faltering/stumbling.

**Final English:** To trample or tread over something while walking. Formed from 足, with 貝 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1377.json)

### `shuowen:1380` — 跇 (yì) — `revised_retained` (English revised)

**Chinese source:** 述也。从足丗聲。

**Decision:** Duan cites musical passage to leap or go beyond great distances; source meaning not mere “to proceed.”

**Final English:** To pass over, leap beyond or traverse. Formed from 足, with 丗 indicating the sound. [Duan proposes reading the received gloss 述 as a corrupted graph 𨒋.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1380.json)

### `shuowen:1389` — 躩 (jué) — `revised_retained` (English revised)

**Chinese source:** 足躩如也。从足矍聲。

**Decision:** Duan quotes Analects commentator 盤辟貌, i.e. shifting about deferentially, not merely running fast.

**Final English:** To move one’s feet in a careful, shifting or ceremonially constrained manner. Formed from 足, with 矍 indicating the sound. [The precise movement described by 躩如 remains context-dependent.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1389.json)

### `shuowen:1406` — 趼 (yàn) — `clear` (English revised)

**Chinese source:** 獸足企也。从足幵聲。

**Decision:** Duan notes raised heels and sure-footed ability to climb high ground.

**Final English:** An animal’s hooves or feet raised on tiptoe, especially when climbing. Formed from 足, with 幵 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1406.json)

### `shuowen:1417` — 疋 (shū) — `revised_retained` (English revised)

**Chinese source:** 足也。上象腓腸，下从止。《弟子職》曰：“問疋何止。”古文以爲《詩·大疋》字。亦以爲足字。或曰胥字。一曰疋，記也。凡疋之屬皆从疋。

**Decision:** Duan distinguishes borrowed 雅 from 疋 and explains the bedding instruction as a question about the elder’s feet.

**Final English:** The foot or lower leg; the upper part is said to depict the calf, and the lower part derives from 止. The Duties of Disciples asks where to place the feet of the bedding. The graph was also borrowed for 雅, “elegant” or the title of the Major Odes, and for 胥; another sense is “to record.” All characters in this category are formed from 疋. [Duan says the transmitted title 大疋 is a corruption of 大雅.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1417.json)

### `shuowen:1441` — 𢆉 (rěn) — `revised_retained` (English revised)

**Chinese source:** 㨖也。从干。入一爲干，入二爲𢆉。讀若能。言稍甚也。

**Decision:** Duan explains “more deeply than 干”, and reads like 飪 rather than 能; received text has obscure damaged character.

**Final English:** To pierce or strike further into something than the related graph 干; its form is explained as entering through two strokes rather than one. Read like 飪. [The received gloss 㨖 and reading 若能 require textual correction in Duan’s analysis.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1441.json)

### `shuowen:1442` — 屰 (nì) — `clear`

**Chinese source:** 不順也。从干下屮。屰之也。

**Decision:** Duan confirms reversed action 不順; source graphic analysis remains historical, not verified palaeography.

**Final English:** Not compliant. Formed from 干 with 屮 below, reversing it.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1442.json)

### `shuowen:1448` — 矞 (yù) — `clear`

**Chinese source:** 以錐有所穿也。从矛从㕯。一曰滿有所出也。

**Decision:** Duan confirms piercing with an awl and alternate outflowing; current English covers both.

**Final English:** To pierce something with an awl. Formed from 矛 and 㕯. Another explanation: something emerging from fullness.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1448.json)

### `shuowen:1457` — 古 (gǔ) — `clear`

**Chinese source:** 故也。从十、口。識前言者也。凡古之屬皆从古。

**Decision:** Duan elaborates 十 as long transmission of earlier spoken words, supporting existing reading.

**Final English:** Old or former. Formed from 十 and 口: remembering earlier words. All characters in the 古 category are formed from 古.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1457.json)

### `shuowen:1467` — 𠦫 (jí) — `revised_retained` (English revised)

**Chinese source:** 詞之𠦫矣。从十咠聲。

**Decision:** Duan restores 辭 and an Odes quotation, cites 毛傳 輯、和也; no certain standalone gloss in base.

**Final English:** Speech brought together or harmonized, associated with the older wording of an Odes line later transmitted with 輯. Formed from 十, with 咠 indicating the sound. [Duan proposes textual corrections to the received gloss 詞之𠦫矣.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1467.json)

### `shuowen:1490` — 𠶷 (yì) — `clear` (English revised)

**Chinese source:** 快也。从言从中。

**Decision:** Duan explicitly defines 快 as 喜, and 中 as achievement of what is desired.

**Final English:** Words that please or bring satisfaction. Formed from 言 and 中.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1490.json)

### `shuowen:1493` — 譔 (zhuàn) — `clear` (English revised)

**Chinese source:** 專教也。从言巽聲。

**Decision:** Duan gives 專壹而教之, cites Guangyun 善言, resolves modern sense.

**Final English:** To teach with focused or undivided attention; another early interpretation relates it to fine or fitting speech. Formed from 言, with 巽 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1493.json)

### `shuowen:1515` — 詧 (chá) — `revised_retained`

**Chinese source:** 言微親詧也。从言，察省聲。

**Decision:** Duan confirms scrutiny of subtle speech; existing draft faithful.

**Final English:** To scrutinize the subtle particulars of speech closely. Formed from 言, with abbreviated 察 indicating the sound. [The wording of the gloss is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1515.json)

### `shuowen:1531` — 誎 (sù) — `checked_retained`

**Chinese source:** 餔旋促也。从言束聲。

**Decision:** Duan says 未聞 and 疑有誤字 concerning 餔旋促; review cannot determine historical expression.

**Final English:** An urgent summons to return, 餔旋促. Formed from 言, with 束 indicating the sound. [The gloss is textually difficult and uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1531.json)

### `shuowen:1557` — 詷 (tóng) — `revised_retained` (English revised)

**Chinese source:** 共也。一曰譀也。从言同聲。《周書》曰：“在夏后之詷。”

**Decision:** Duan explains 言過 and presents variation in 顧命 quote, so retain flag.

**Final English:** Shared or in common; another explanation is excessive or boastful speech. Formed from 言, with 同 indicating the sound. The Documents cites its use in an early Zhou passage. [Duan documents significant textual variants in the cited phrase.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1557.json)

### `shuowen:1575` — 訝 (yà) — `clear`

**Chinese source:** 相迎也。从言牙聲。《周禮》曰：“諸侯有卿訝發。”

**Decision:** Duan confirms mutual reception or greeting and the connection to modern 迓; original English faithful.

**Final English:** To receive one another. Formed from 言, with 牙 indicating the sound. The Rites of Zhou says: “Feudal lords have a minister to receive arrivals.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1575.json)

### `shuowen:1576` — 詣 (yì) — `clear` (English revised)

**Chinese source:** 𠋫至也。从言旨聲。

**Decision:** Duan interprets 候至 as arriving at an appointed moment; improves “attend and arrive”.

**Final English:** To arrive at a place deliberately, as at an appointment or specific destination. Formed from 言, with 旨 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1576.json)

### `shuowen:1581` — 謯 (jiē) — `checked_retained`

**Chinese source:** 謯，娽也。从言虘聲。

**Decision:** Duan explicitly says its meaning is unknown (其義則未聞), so flag must stay.

**Final English:** 謯 means 娽, apparently attentive or repeated speech. Formed from 言, with 虘 indicating the sound. [The rare cross-gloss is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1581.json)

### `shuowen:1596` — 謺 (zhé) — `checked_retained`

**Chinese source:** 謺讘也。从言執聲。

**Decision:** Duan notes later rearrangement of the source text and only characterizes 謺讘 as a compound; exact sense unverified.

**Final English:** The expression 謺讘, apparently repeated or whispered speech. Formed from 言, with 執 indicating the sound. [The descriptive sense is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1596.json)

### `shuowen:1597` — 謰 (lián) — `revised_retained` (English revised)

**Chinese source:** 謰謱也。从言連聲。

**Decision:** Duan quotes Fangyan listing 謰謱 among disputed/jumbled words but precise force ambiguous.

**Final English:** Entangled, contentious or over-complicated speech, as in the paired expression 謰謱. Formed from 言, with 連 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1597.json)

### `shuowen:1598` — 謱 (lóu) — `revised_retained` (English revised)

**Chinese source:** 謰謱也。从言婁聲。

**Decision:** See paired entry 1597 and Fangyan evidence cited by Duan.

**Final English:** Entangled, contentious or over-complicated speech, as in the paired expression 謰謱. Formed from 言, with 婁 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1598.json)

### `shuowen:1600` — 謲 (càn) — `checked_retained`

**Chinese source:** 相怒使也。从言參聲。

**Decision:** Duan does not expand on the reciprocal angry imperative sense; uncertainty cannot be cleared on source alone.

**Final English:** To order one another angrily. Formed from 言, with 參 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1600.json)

### `shuowen:1611` — 詛 (zǔ) — `checked_retained`

**Chinese source:** 詶也。从言且聲。

**Decision:** Unexplained cross-gloss 詶 and absence of substantive Duan commentary; avoid assuming it is always a curse.

**Final English:** To curse or invoke against, 詶. Formed from 言, with 且 indicating the sound. [The cross-gloss is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1611.json)

### `shuowen:1612` — 䛆 (zhòu) — `revised_retained` (English revised)

**Chinese source:** 詶也。从言由聲。

**Decision:** Duan speculates about relation to a ritual graph, rather than confirming a curse.

**Final English:** A speech-act cross-referenced by the obscure graph 詶; possibly ritual invocation or cursing. Formed from 言, with 由 indicating the sound. [Duan suggests a relation to a blessing/invocation graph 祝䄂, but this does not settle the meaning.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1612.json)

### `shuowen:1618` — 誒 (xī) — `clear` (English revised)

**Chinese source:** 可惡之辭。从言矣聲。一曰誒然。《春秋傳》曰：“誒誒出出。”

**Decision:** Duan cites exasperated sighs and a dialectal affirmative sense, clarifying two uses.

**Final English:** An interjection expressing dislike, regret or an exasperated sigh. Formed from 言, with 矣 indicating the sound. Another sense is an affirmative exclamation; the Spring and Autumn commentary records a repeated exclamation.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1618.json)

### `shuowen:1623` — 訾 (zǐ) — `clear` (English revised)

**Chinese source:** 不思稱意也。从言此聲。《詩》曰：“翕翕訿訿。”

**Decision:** Duan quotes Mao and Erya, distinguishing careless calumny from merely “expressing one’s mind”.

**Final English:** To speak against someone without considering how to repay their favors or honor their position; in the Odes, repeated 訿訿 describes the failure to discharge duties. Formed from 言, with 此 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1623.json)

### `shuowen:1633` — 𧥣 (kòu) — `clear` (English revised)

**Chinese source:** 扣也。如求婦先𧥣叕之。从言从口，口亦聲。

**Decision:** Duan connects this to knocking or inquiring, 叩, and interprets marriage-contact metaphor.

**Final English:** To sound someone out or make inquiries, as when approaching a prospective marriage and first making connected inquiries. Formed from 言 and 口; 口 also indicates the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1633.json)

### `shuowen:1634` — 誽 (nì) — `clear` (English revised)

**Chinese source:** 言相誽司也。从言兒聲。

**Decision:** Duan explicitly says 誽司猶刺探, resolved.

**Final English:** To probe or investigate what another person says; figuratively, to spy or pry. Formed from 言, with 兒 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1634.json)

### `shuowen:1644` — 詪 (hěn) — `revised_retained` (English revised)

**Chinese source:** 眼戾也。从言𥃩聲。

**Decision:** Duan cites Guangyun as 難語貌; received 眼戾 may be corrupt.

**Final English:** Difficult, harsh or awkward speech. Formed from 言, with 𥃩 indicating the sound. [The transmitted gloss 眼戾 contrasts with the dictionary interpretation 難語貌.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1644.json)

### `shuowen:1666` — 訏 (xū) — `revised_retained` (English revised)

**Chinese source:** 詭譌也。从言于聲。一曰訏，𧪰。齊、楚謂信曰訏。

**Decision:** Duan compares Erya and Fangyan: 訏、大也 between Qi and Chu; received 信 possibly error.

**Final English:** Deceptive or distorted speech. Formed from 言, with 于 indicating the sound. Another explanation concerns an exclamation; in a regional usage it means “great” or “large.” [Duan proposes 大 in place of received 信.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1666.json)

### `shuowen:1669` — 謵 (xí) — `checked_retained`

**Chinese source:** 言謵讋也。从言習聲。

**Decision:** Duan suspects missing words and describes 谵/謵讋 as an obscure binome; cannot clear.

**Final English:** Faltering or fearful speech, 謵讋. Formed from 言, with 習 indicating the sound. [The exact descriptive sense is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1669.json)

### `shuowen:1670` — 䛩 (wù) — `revised_retained`

**Chinese source:** 相毀也。从言亞聲。一曰畏亞。

**Decision:** Duan confirms the reciprocal insulting sense and the alternative expressing aversion; draft acceptable.

**Final English:** To defame one another. Formed from 言, with 亞 indicating the sound. Another explanation: fear or submission, 畏亞. [The final expression is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1670.json)

### `shuowen:1694` — 詘 (qū) — `clear`

**Chinese source:** 詰詘也。一曰屈襞。从言出聲。

**Decision:** Duan distinguishes speech that challenges/constrains from the alternate folding sense; original English adequate.

**Final English:** To question and confound, 詰詘. Another explanation: to bend and fold. Formed from 言, with 出 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1694.json)

### `shuowen:1701` — 讕 (lán) — `clear` (English revised)

**Chinese source:** 怟讕也。从言闌聲。

**Decision:** Duan links 抵讕 to modern 抵賴, resisting or denying blame. Original “to deny” correct but underexplained.

**Final English:** To deny or brazenly dispute a charge, or to evade responsibility. Formed from 言, with 闌 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1701.json)

### `shuowen:1714` — 該 (gāi) — `clear`

**Chinese source:** 軍中約也。从言亥聲。讀若心中滿該。

**Decision:** Duan confirms a military agreement and separate sense of satiation in 讀若; existing English adequate.

**Final English:** An agreement or signal within an army. Formed from 言, with 亥 indicating the sound. Read like 該 in “the heart full.” [The pronunciation phrase is obscure.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1714.json)

### `shuowen:1723` — 𧩮 (xiǎo) — `checked_retained`

**Chinese source:** 小也。誘也。从言叜聲。《禮記》曰：“足以𧩮聞。”

**Decision:** Source first clause 小也 and second 誘也 appear unrelated; no reliable note from Duan. Keep.

**Final English:** Small; to entice. Formed from 言, with 叜 indicating the sound. The Record of Rites says: “Enough to entice one's hearing.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1723.json)

### `shuowen:1744` — 對 (duì) — `clear` (English revised)

**Chinese source:** 譍無方也。从丵从口从寸。

**Decision:** Duan cites a skilled respondent answering appropriately depending on a question, interpreting 无方 as flexible response.

**Final English:** To answer or respond in a way suited to the question, rather than by a fixed formula. Formed from 丵, 口 and 寸.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1744.json)

### `shuowen:1745` — 菐 (pú) — `clear` (English revised)

**Chinese source:** 瀆菐也。从丵从廾，廾亦聲。凡菐之屬皆从菐。

**Decision:** Duan cites 孟子 僕僕 and explains 煩猥貌, resolving the original vague gloss.

**Final English:** To press importunately or repeatedly trouble someone, as in the expression 瀆菐. Formed from 丵 and 廾; 廾 also indicates the sound. All characters in the 菐 category are formed from 菐.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1745.json)

### `shuowen:1751` — 奐 (huàn) — `revised_retained` (English revised)

**Chinese source:** 取奐也。一曰大也。从廾，夐省。

**Decision:** Duan says 未聞 for 取奐 and cites literary use of “splendid/large”; retain flag.

**Final English:** Large, spacious or splendid; an alternative sense related to taking or seizing is reported but remains obscure. Formed from 廾 and an abbreviated 夐. [Duan states that the first gloss 取奐 is not understood.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1751.json)

### `shuowen:1766` — 樊 (fán) — `clear` (English revised)

**Chinese source:** 鷙不行也。从𠬜从棥，棥亦聲。

**Decision:** Duan identifies 驇不行, stagnating or preventing movement, and cage sense.

**Final English:** To restrain or impede movement; by extension an enclosure or cage. Formed from 𠬜 and 棥; 棥 also indicates the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1766.json)

### `shuowen:1776` — 𦥑 (jū) — `revised_retained` (English revised)

**Chinese source:** 叉手也。从纟、纠。凡𦥑之屬皆从𦥑。

**Decision:** Duan interprets facing fingertips and shows corrupt digital component mapping, not 纟/纠, which should not appear in the Han graph analysis.

**Final English:** Hands crossed or placed facing each other, their fingers directed inward. All characters in the 𦥑 category are formed from 𦥑. [The digital source has corrupt simplified graph components 纟 and 纠, so no literal component analysis should be asserted.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1776.json)

### `shuowen:1778` — 䢅 (chén) — `clear`

**Chinese source:** 早昧爽也。从𦥑从辰。辰，時也。辰亦聲。𠃨夕爲𡖊，臼辰爲䢅，皆同意。凡䢅之屬皆从䢅。

**Decision:** Duan confirms early daybreak and 會意 analysis; original wording adequate.

**Final English:** Early dawn, when dimness clears. Formed from 𦥑 and 辰; 辰 means time and also indicates the sound. 𠃨 with 夕 makes 𡖊; 臼 with 辰 makes 䢅, both sharing the same idea. All characters in the 䢅 category are formed from 䢅.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1778.json)

### `shuowen:1794` — 鞔 (mán) — `clear` (English revised)

**Chinese source:** 履空也。从革免聲。

**Decision:** Duan identifies 鞵幫, the shoe upper, not a free-standing hollow shoe.

**Final English:** The hollow leather upper or side of a shoe; by extension, a covering of leather. Formed from 革, with 免 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1794.json)

### `shuowen:1803` — 鞀 (táo) — `clear` (English revised)

**Chinese source:** 鞀遼也。从革召聲。

**Decision:** Duan cites Zhouli: small handled drum that strikes itself as it shakes. Resolves obscure 鞀遼.

**Final English:** A small hand drum shaken by its handle, whose side pellets strike its faces. Formed from 革, with 召 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1803.json)

### `shuowen:1810` — 𩎑 (zuān) — `revised_retained` (English revised)

**Chinese source:** 車衡三束也。曲轅𩎈縛，直轅𨏉縛。从革爨聲。讀若《論語》“鑽燧”之“鑽”。

**Decision:** Duan corrects 車衡三束 to 車句衡五束 and comments on vehicle engineering. Preserve transmitted Chinese.

**Final English:** The leather bindings fitted to a carriage pole or crossbar. The received text distinguishes bent and straight shafts. Formed from 革, with 爨 indicating the sound; pronounced like 鑽 in the Analects. [Duan argues the received numeral three should be five, and that the technical descriptions are damaged.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1810.json)

### `shuowen:1813` — 鞥 (ēng) — `clear` (English revised)

**Chinese source:** 轡鞥。从革弇聲。讀若譍。一曰龍頭繞者。

**Decision:** Duan explains 轡鞥 and 龓頭 as the horse’s headstall; solves 龍/龓 corruption by stating function.

**Final English:** A bridle, particularly the straps encircling a horse’s head. Formed from 革, with 弇 indicating the sound. Read like 譍.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1813.json)

### `shuowen:1815` — 𩎍 (xiǎn) — `revised_retained` (English revised)

**Chinese source:** 著掖鞥也。从革顯聲。

**Decision:** Duan 亦/腋 versus 掖 and 靼 versus 鞥; retain uncertainty about technical construction.

**Final English:** Leather harness straps that pass beneath or near a horse’s flanks. Formed from 革, with 顯 indicating the sound. [Duan argues both the anatomical term and the cross-referenced strap-name in the received text are corrupted.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1815.json)

### `shuowen:1817` — 䩶 (chěng) — `revised_retained` (English revised)

**Chinese source:** 驂具也。从革𧈪聲。讀若騁蜃。

**Decision:** Duan explicitly questions 騁蜃 and suggests two readings separated by 又.

**Final English:** Harness equipment for a side horse in a team. Formed from 革, with 𧈪 indicating the sound. The text gives readings resembling 騁 and 蜃. [Duan finds the second pronunciation clause corrupt.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1817.json)

### `shuowen:1821` — 䩒 (yú) — `revised_retained` (English revised)

**Chinese source:** 輨内環靼也。从革于聲。

**Decision:** Duan notes source 輨 corrupted from 䩪, reinterprets leather wrap.

**Final English:** A leather loop or strap fitted within a carriage axle cap. Formed from 革, with 于 indicating the sound. [Duan questions the transmitted first component-name 輨.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1821.json)

### `shuowen:1832` — 靲 (qín) — `revised_retained` (English revised)

**Chinese source:** 鞮也。从革今聲。

**Decision:** Duan explicitly: 說文靲字殆後人所增, not safely original to Xu.

**Final English:** A leather shoe or strap, related to 鞮 or 鞻. Formed from 革, with 今 indicating the sound. [Duan suspects the entry may be a later insertion into Shuowen.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1832.json)

### `shuowen:1859` — 䰜 (lì) — `revised_retained` (English revised)

**Chinese source:** 㽁也。古文亦鬲字。象孰飪五味气上出也。凡䰜之屬皆从𩰲。

**Decision:** Duan distinguishes archaic vessel form and vapors; 㽁 gloss likely added.

**Final English:** A vessel for cooking, also an archaic form of 鬲. It depicts cooking vapors rising from the vessel. All characters in the 䰜 category are formed from the same cooking-vessel graph. [Duan considers the transmitted initial 㽁 gloss an interpolation.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1859.json)

### `shuowen:1864` — 𩱫 (sù) — `revised_retained` (English revised)

**Chinese source:** 鼎實。惟葦及蒲。陳畱謂䭈爲𩱫。从𩰲速聲。

**Decision:** Duan compares Shijing its vegetables are 筍 and 蒲, contrasts meat/vegetables and gruel; source text 惟葦 variant remains.

**Final English:** The vegetable ingredients placed in a cooking cauldron, such as bamboo shoots and cattail shoots; in Chenliu dialect it could refer to a rice-based stew or thick porridge. Formed from 𩰲, with 速 indicating the sound. [Duan regards the transmitted 葦 (“reeds”) as a variant of 筍 (“bamboo shoots”), and the source gloss is damaged.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1864.json)

### `shuowen:1870` — 䰞 (zhǔ) — `revised_retained` (English revised)

**Chinese source:** 孚也。从𩰲者聲。

**Decision:** Duan notes 䰞下當云𩰱也, cooking/boiling, not 孚.

**Final English:** To boil or cook food in a vessel. Formed from 𩰲, with 者 indicating the sound. [Duan suggests that the transmitted gloss 孚 is corrupt and should refer to cooking (𩰱).]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1870.json)

### `shuowen:1877` — 𡎐 (yì) — `clear` (English revised)

**Chinese source:** 種也。从坴、丮。持亟種之。《書》曰：“我𡎐黍稷。”

**Decision:** Duan confirms planting and distinguishes old graph 埶 from later 蓺/藝.

**Final English:** To sow or cultivate plants, especially grain. Formed from 坴 and 丮, depicting hands taking seeds and planting them. The Documents says: “I sowed millet and panicled millet.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1877.json)

### `shuowen:1881` — 谻 (jué) — `revised_retained` (English revised)

**Chinese source:** 相踦之也。从丮𧮫聲。

**Decision:** Duan states 踦當作掎, pointing from leg action to grasping/holding.

**Final English:** To prop, grasp or pull against something, in the sense of 掎 (“to hold back or pull”). Formed from 丮, with 𧮫 indicating the sound. [Duan corrects the transmitted 踦 to 掎.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1881.json)

### `shuowen:1905` — 夬 (guài) — `clear` (English revised)

**Chinese source:** 分決也。从又，纡象決形。

**Decision:** Duan cites Yijing 夬決也, makes glyph clear; draft correct but source uses corrupted 纡.

**Final English:** To divide or cut apart decisively. Formed from 又; an additional curved stroke depicts the act of splitting or separation.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1905.json)

### `shuowen:1907` — 𠭯 (zhā) — `revised_retained` (English revised)

**Chinese source:** 又卑也。从又虘聲。

**Decision:** Duan uses Fangyan 抯摣取也; original “low” sense incomplete.

**Final English:** To reach down and take something by hand; by extension, to retrieve something from mud or a ditch. Formed from 又, with 虘 indicating the sound. [Duan corrects the received 又卑, comparing the character 叉 and an older variant.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1907.json)

### `shuowen:1914` — 𠬢 (tāo) — `revised_retained` (English revised)

**Chinese source:** 滑也。《詩》云：“𠬢兮達兮。”从又、屮。一曰取也。

**Decision:** Duan glosses 滑 here as smooth motion and compares Odes 挑兮達兮; the quotation is textually variable.

**Final English:** Moving freely or smoothly, as in an old Odes expression for coming and going; another meaning is “to take.” Formed from 又 and 屮. [Duan argues for alternative source characters in the Odes quotation.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1914.json)

### `shuowen:1921` — 友 (yǒu) — `clear` (English revised)

**Chinese source:** 同𢖽爲友。从二又。相交友也。

**Decision:** Duan cites Zhouli 同志曰友, clarifies source 同𢖽, and adds gestures of mutual aid.

**Final English:** People sharing the same aims or commitments are friends. Depicts two hands, representing mutual connection.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1921.json)

### `shuowen:1948` — 殳 (shū) — `revised_retained` (English revised)

**Chinese source:** 以杸殊人也。《禮》：“殳以積竹，八觚，長丈二尺，建於兵車，車旅賁以先驅。”从又几聲。凡殳之屬皆从殳。

**Decision:** Duan restores 杖 and explains 杸/殳 without blade, used to separate or ward off opponents; source differs on precise dimensions.

**Final English:** A staff-like weapon used to strike or keep an opponent at a distance, traditionally a long, many-sided bamboo pole carried on a military carriage; its name was associated with separating people. Formed from 又, with 几 indicating the sound. All characters in the 殳 category are formed from 殳. [Duan questions received wording and cites weapon dimensions from Zhouli.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1948.json)

### `shuowen:1949` — 祋 (duì) — `clear`

**Chinese source:** 殳也。从殳示聲。或說城郭市里，高縣羊皮，有不當入而欲入者，暫下以驚牛馬曰祋。故从示、殳。《詩》曰：“何戈與祋。”

**Decision:** Duan confirms 殳 weapon and alternative warning suspended hide; English sufficient.

**Final English:** A 殳 staff. Formed from 殳, with 示 indicating the sound. Another account: at city walls, markets and lanes a sheepskin is hung high; when someone not entitled to enter tries to do so, it is briefly lowered to frighten cattle and horses, called 祋. Hence formed from 示 and 殳. The Odes says: “Carrying dagger-axes and 祋.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1949.json)

### `shuowen:1954` — 𣪌 (tóu) — `revised_retained` (English revised)

**Chinese source:** 繇擊也。从殳豆聲。古文祋如此。

**Decision:** Duan explicitly reads 繇擊 as 遙擊, and argues ancient form label was miscopied.

**Final English:** To strike someone or something from a distance. Formed from 殳, with 豆 indicating the sound. [Duan treats the received “ancient form of 祋” as a corruption of 投 and distinguishes this from the hand-radical character.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1954.json)

### `shuowen:1955` — 𣫐 (chóu) — `revised_retained`

**Chinese source:** 縣物𣪐擊。从殳𠃬聲。

**Decision:** Duan cross-links the suspended-object or striking gloss to a hand-mallet; existing English plausible.

**Final English:** To strike a suspended object. Formed from 殳, with 𠃬 indicating the sound. [The action described by 𣪐 is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1955.json)

### `shuowen:1970` — 𠘧 (shū) — `checked_retained`

**Chinese source:** 鳥之短羽飛𠘧𠘧也。象形。凡𠘧之屬皆从𠘧。讀若殊。

**Decision:** Duan gives little direct semantic detail on the obsolete pictogram, and unusual phrase 鳥之短羽飛𠘧𠘧 remains only partially understood.

**Final English:** A short-feathered bird flying in the manner 𠘧𠘧. A pictograph. All characters in the 𠘧 category are formed from 𠘧. Read like 殊. [The precise flight description is uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1970.json)

### `shuowen:1977` — 專 (zhuān) — `revised_retained` (English revised)

**Chinese source:** 六寸簿也。从寸叀聲。一曰專，紡專。

**Decision:** Duan identifies a 笏, or official writing tablet, and a 纺专 spinning weight; the transmitted measurement may be defective.

**Final English:** A narrow writing tablet used for recording an official’s notes; the transmitted text describes it as six cun long. Formed from 寸, with 叀 indicating the sound. Another meaning is a spindle whorl used in spinning. [Duan argues the tablet was a 笏 and queries the transmitted length.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1977.json)

### `shuowen:1986` — 𤮪 (jùn) — `checked_retained`

**Chinese source:** 羽獵韋絝。从㼱灷聲。

**Decision:** Duan interprets soft leather trousers associated with feathered hunting, but explicitly notes damaged/omitted source components and uncertainties concerning 灷.

**Final English:** Leather trousers for hunting with feathered banners. Formed from 㼱, with 灷 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1986.json)

### `shuowen:1994` — 敀 (pò) — `revised_retained` (English revised)

**Chinese source:** 迮也。从攴白聲。《周書》曰：“常敀常任。”

**Decision:** Duan glosses 迮 as 起 and says the Documents source employs 敀 as a loan for 伯; avoid reading the quoted word literally as oppression.

**Final English:** To cause to rise or press into action. Formed from 攴, with 白 indicating the sound. The quotation from the Documents has a graphic loan apparently corresponding to an official rank/title, “the regular senior officials.” [The received reading differs from the transmitted 尚書.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/1994.json)

### `shuowen:2004` — 𣿊 (liàn) — `clear` (English revised)

**Chinese source:** 辟𣿊鐵也。从攴从湅。

**Decision:** Duan explains repeated folding/hammering in metalwork, comparing 百辟寶劔.

**Final English:** To repeatedly fold, forge and refine iron in making steel. Formed from 攴 and 湅.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2004.json)

### `shuowen:2006` — 攽 (bān) — `revised_retained` (English revised)

**Chinese source:** 分也。从攴分聲。《周書》曰：“乃惟孺子攽。”亦讀與彬同。

**Decision:** Duan explains 攽 as an older graph for distribution, with 頒 a later loan; quoted line has received discrepancies.

**Final English:** To divide or distribute. Formed from 攴, with 分 indicating the sound. The Documents quotation writes a form that corresponds to 頒 in later editions. Also pronounced like 彬. [The quoted sentence requires textual collation before translation.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2006.json)

### `shuowen:2007` — 𢽎 (hàn) — `revised_retained` (English revised)

**Chinese source:** 止也。从攴旱聲。《周書》曰：“𢽎我于艱。”

**Decision:** Duan explicitly identifies 𢽎 as old graph of 扞; the Documents has the later graph.

**Final English:** To fend off, restrain or defend against something. Formed from 攴, with 旱 indicating the sound. The Documents quotation uses this character for later 扞, “protect or defend me in difficulties.” [The received quotation needs collation.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2007.json)

### `shuowen:2026` — 攸 (yōu) — `clear` (English revised)

**Chinese source:** 行水也。从攴从人，水省。

**Decision:** Duan reads the word as tranquil flowing, contrasting with the terse 行水 in the received text.

**Final English:** The gentle, orderly flow of water. Formed from 攴 and 人, with a reduced water element.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2026.json)

### `shuowen:2045` — 敲 (qiāo) — `clear` (English revised)

**Chinese source:** 橫擿也。从攴高聲。

**Decision:** Duan explains 橫擿 as 橫投 and cites the classical act of striking someone with a staff.

**Final English:** To strike or hit sideways, for example by swinging or throwing a stick. Formed from 攴, with 高 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2045.json)

### `shuowen:2208` — 𥆞 (juàn) — `revised_retained` (English revised)

**Chinese source:** 目圍也。从䀠、纾。讀若書卷之卷。古文以爲醜字。

**Decision:** Duan reads 目回 rather than 目圍 and reconstructs 靦 rather than 醜 as an ancient-script loan; both transmitted elements are doubtful.

**Final English:** To turn or move one’s gaze back, as when looking around. Formed from 䀠 and an additional graph; pronounced like 卷 in 書卷. Ancient writing also used it for 靦. [The transmitted component 纾 and variant 醜 conflict with Duan’s reconstruction.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2208.json)

### `shuowen:2216` — 𦤝 (mián) — `checked_retained`

**Chinese source:** 宮不見也。闕。

**Decision:** Duan links the obscure gloss to closely enclosed hidden rooms and marks the graphic explanation itself 闕; no secure restoration of the headword meaning.

**Final English:** A palace or chamber not seen. The explanation is missing. [The recorded gloss 宮不見 is difficult.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2216.json)

### `shuowen:2220` — 者 (zhě) — `revised_retained` (English revised)

**Chinese source:** 別事詞也。从𪞶纺聲。纺，古文旅字。

**Decision:** Duan explains 別事詞 as introducing and specifying a matter; transcribed phonetic 纺 is not reliable.

**Final English:** A grammatical particle used to distinguish or specify a subject or matter. Formed from 𪞶, with an ancient form of 旅 serving as phonetic. [The transmitted graph 纺 is corrupted; Duan points to 𣥐 as the older phonetic.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2220.json)

### `shuowen:2221` — 㿧 (chóu) — `revised_retained` (English revised)

**Chinese source:** 詞也。从𪞶𢏚聲。𢏚與疇同。《虞書》：“帝曰：𤾊咨。”

**Decision:** Duan reconstructs 誰詞也 and identifies the 疇咨 passages from the Documents; do not translate the headword merely as a vague particle.

**Final English:** An interrogative word meaning “who?” or “which person?”, represented by a graph corresponding to 疇. Formed with 𢏚 as phonetic. The cited Documents dialogue asks whom to consult. [The received “詞也” omits the question gloss, which Duan supplies from parallel texts.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2221.json)

### `shuowen:2223` — 百 (bǎi) — `revised_retained` (English revised)

**Chinese source:** 十十也。从一、𪞶。數，十百爲一貫。相章也。

**Decision:** Duan discusses omitted words and corruption of 相/貫 and interprets 百 as “ten tens”; avoid conjectural literal translation of defective second clause.

**Final English:** One hundred: ten groups of ten. Formed from 一 and an upper white-like component. The traditional graphic explanation connects counting and a complete string of units. [The remainder of the transmitted explanation has suffered textual corruption.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2223.json)

### `shuowen:2224` — 鼻 (bí) — `clear` (English revised)

**Chinese source:** 引气自𢌿也。从自、𢌿。凡鼻之屬皆从鼻。

**Decision:** Duan relates the gloss to nasal inhalation and gives the corresponding semantic formula for the nose.

**Final English:** The nose, the organ through which breath is drawn. Formed from 自 and 𢌿. All characters in the 鼻 group are formed from 鼻.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2224.json)

### `shuowen:2239` — 翦 (jiǎn) — `clear` (English revised)

**Chinese source:** 羽生也。一曰𠂕羽。从羽前聲。

**Decision:** Duan explains the alternative in context of arrows whose flights are cut short to balance an arrow.

**Final English:** Feathers growing out evenly; alternatively, the feathers of an arrow trimmed to a regular, shortened length. Formed from 羽, with 前 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2239.json)

### `shuowen:2247` — 𦐧 (yì) — `revised_retained` (English revised)

**Chinese source:** 羽之𦐧風。亦古諸侯也。一曰射師。从羽幵聲。

**Decision:** Duan links the word to 羿, a legendary archer, and another Xia-era lord, but the wing phrase itself remains difficult.

**Final English:** An old word associated with wings rising or beating against wind; also the name 羿 of an ancient lord or skilled archer. Formed from 羽, with 幵 indicating the sound. [Duan distinguishes at least two figures named 羿 and proposes a different reading for the wing phrase.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/2247.json)

### `shuowen:3511` — 枒 (yá) — `revised_retained` (English revised)

**Chinese source:** 木也。从木牙聲。一曰車𨊾會也。

**Decision:** Duan describes an exotic palm-like tree and corrects the carriage component to the wheel rim, 網/輮.

**Final English:** A kind of palm-like tree whose fruits hang at the top; another sense refers to the joining of the curved wooden rim of a chariot wheel. Formed from 木, with 牙 indicating the sound. [Precise historical botanical identification is not certain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/3511.json)

### `shuowen:3514` — 梂 (qiú) — `revised_retained` (English revised)

**Chinese source:** 櫟實。一曰𨯳首。从木求聲。

**Decision:** Duan links the botanical gloss to clusters of seed capsules and the tool gloss to a chisel handle; identifies distinct usages.

**Final English:** The clustered or cup-like seed casing of certain trees, traditionally described as the fruit of 櫟. Another explanation: the wooden head or handle of a boring implement. Formed from 木, with 求 indicating the sound. [The botanical and tool identifications vary among commentaries.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/3514.json)

### `shuowen:3526` — 梗 (gěng) — `revised_retained` (English revised)

**Chinese source:** 山枌榆。有朿，莢可爲蕪夷者。从木更聲。

**Decision:** Duan contrasts the thorny mountain elm identification of Shuowen with later botanical accounts; natural species identification disputed.

**Final English:** A spiny variety of mountain elm whose seed pods can be processed to make 蕪夷, a traditional aromatic medicinal preparation. Formed from 木, with 更 indicating the sound. [Commentaries differ over the exact elm species.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/3526.json)

### `shuowen:3564` — 䯂 (shēn) — `revised_retained` (English revised)

**Chinese source:** 眾盛也。从木驫聲。《逸周書》曰：“疑沮事。”闕。

**Decision:** Duan interprets the rare 逸周書 phrase, and discusses omitted or inserted characters and the phonetic analysis.

**Final English:** Numerous and flourishing. Formed from 木, with 驫 indicating the sound. In a quotation from the Lost Documents of Zhou, the graph may refer to accumulating doubts that impede affairs. [Duan regards the final 闕 as a later addition and disputes parts of the transmitted quotation.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/3564.json)

### `shuowen:3600` — 㮝 (hé) — `checked_retained`

**Chinese source:** 角械也。从木卻聲。一曰木下白也。

**Decision:** Duan interprets 角械 as equipment used in wrestling or contest but states 一曰木下白 is 未詳; preserve uncertainty.

**Final English:** A horn-shaped implement. Formed from 木, with 卻 indicating the sound. Another explanation: the white part beneath wood. Both descriptions are uncertain.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/3600.json)

### `shuowen:3630` — 橝 (tán) — `clear` (English revised)

**Chinese source:** 屋梠前也。从木覃聲。一曰蠶槌。

**Decision:** Duan clarifies the roof construction and independently identifies the sericultural tool.

**Final English:** A timber in front of the roof’s eaves, between the eaves-beam and its front edge. Another meaning: a mallet used in sericulture. Formed from 木, with 覃 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/3630.json)

### `shuowen:3660` — 桱 (jīng) — `clear` (English revised)

**Chinese source:** 桱桯也，東方謂之蕩。从木坙聲。

**Decision:** Duan explicitly: 桱蕩皆牀前几之殊語也.

**Final English:** A low stand or small table placed at the front of a bed, also called 簜 in eastern dialects. Formed from 木, with 坙 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/3660.json)

### `shuowen:3671` — 㭒 (sì) — `revised_retained` (English revised)

**Chinese source:** 臿也。从木㠯聲。一曰徙土輂，齊人語也。

**Decision:** Duan identifies a spade or shovel, discusses carrying earth, and identifies variant wording in the Qi dialect.

**Final English:** A digging tool, spade or shovel. Formed from 木, with 㠯 indicating the sound. Another use in the Qi dialect refers to an implement for moving earth, potentially a soil-carrying tray or barrow. [The source’s 纪 is corrupt, and Duan suggests rearranging the alternative-gloss wording.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/3671.json)

### `shuowen:4842` — 㡆 (huāng) — `clear` (English revised)

**Chinese source:** 設色之工，治絲練者。从巾𡿬聲。一曰𢂩隔。讀若荒。

**Decision:** Duan cites Kaogongji 㡆氏 as specialists in refining silk and explains the covering sense.

**Final English:** A craftsman who prepares, scours and bleaches silk thread and woven silk. Formed from 巾, with 𡿬 indicating the sound. Alternatively, a covering or netting placed above something. Pronounced like 荒.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/4842.json)

### `shuowen:4886` — 𢅼 (néi) — `revised_retained` (English revised)

**Chinese source:** 𡎰地，以巾𢵢之。从巾夒聲。讀若水溫㬮也。一曰箸也。

**Decision:** Duan connects the word with specialist plastering and rubbing wet plaster smooth; traces extensive textual/graphic corruptions.

**Final English:** To smooth or wipe a freshly plastered surface with cloth, as a skilled plasterer would. Formed from 巾, with a phonetic graph transmitted as 夒. Another sense: to apply or affix something. [The headword, phonetic graph and rare pronunciation gloss have a complex textual history.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/4886.json)

### `shuowen:4904` — 𢂷 (jiá) — `clear` (English revised)

**Chinese source:** 士無巿有𢂷。制如榼，缺四角。爵弁服，其色韎。賤不得與裳同。司農曰：“裳，纁色。”从巿合聲。

**Decision:** Duan reconstructs the ritual dress item 韐 and explains leather, cut corners, rank differentiation and madder dye.

**Final English:** A reddish leather ceremonial apron worn with a scholar-official’s jue-cap ritual costume instead of the higher-rank apron. It was cut into a distinctive four-cornered shape, and its color differed from the wearer’s skirt. Formed from 巿, with 合 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/4904.json)

### `shuowen:4974` — 僤 (dàn) — `clear` (English revised)

**Chinese source:** 疾也。从人單聲。《周禮》曰：“句兵欲無僤。”

**Decision:** Duan 速疾 and Zhouli “句兵欲無僤” compared with transmitted “欲無彈”.

**Final English:** Rapid or swift. Formed from 人, with 單 indicating the sound. The Rites of Zhou says that hooked weapons should not be too quick or springy in action.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/4974.json)

### `shuowen:5037` — 儃 (chán) — `revised_retained` (English revised)

**Chinese source:** 儃何也。从人亶聲。

**Decision:** Duan explicitly labels the received phrase 未聞 and suggests a tentative text-level emendation rather than a certain translation.

**Final English:** The rare expression 儃何, perhaps referring to circling, lingering or turning about. Formed from 人, with 亶 indicating the sound. [Duan says the received gloss is unexplained and proposes a possible connection with 儃佪 in classical poetry.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/5037.json)

### `shuowen:5069` — 俒 (hùn) — `revised_retained` (English revised)

**Chinese source:** 完也。《逸周書》曰：“朕實不明，以俒伯父。”从人从完。

**Decision:** Duan explains a lexical loan of 俒 for 慁/溷 in the quotation, distinguishing original 完 meaning.

**Final English:** To be complete or whole. In the quoted Lost Book of Zhou passage the character appears to be a loan meaning “to trouble or inconvenience”: “I have lacked understanding and have troubled my uncle.” Formed from 人 and 完. [Textual variants and the original line’s context remain uncertain.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/5069.json)

### `shuowen:5076` — 使 (shǐ) — `clear` (English revised)

**Chinese source:** 伶也。从人吏聲。

**Decision:** Duan explicitly: 大徐令作伶, 誤; valid original command sense established.

**Final English:** To order, command or dispatch someone. Formed from 人, with 吏 indicating the sound. [The received source has 伶 for 令, which Duan identifies as a scribal error.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/5076.json)

### `shuowen:5104` — 佻 (tiāo) — `clear` (English revised)

**Chinese source:** 愉也。从人兆聲。《詩》曰：“視民不佻。”

**Decision:** Duan reads 愉 in its older “shallow/frivolous” sense rather than later “joy”, and clarifies the poem.

**Final English:** Frivolous, careless or lacking seriousness. Formed from 人, with 兆 indicating the sound. The Odes says: “He does not treat the people frivolously.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/5104.json)

### `shuowen:6811` — 慲 (mán) — `clear` (English revised)

**Chinese source:** 忘也。慲兜也。从心㒼聲。

**Decision:** Duan explicitly compares 慲兜 with 糊塗不省事.

**Final English:** Forgetful, confused or muddleheaded, as in the old expression 慲兜. Formed from 心, with 㒼 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/6811.json)

### `shuowen:6815` — 悝 (kuī) — `clear` (English revised)

**Chinese source:** 啁也。从心里聲。《春秋傳》有孔悝。一曰病也。

**Decision:** Duan identifies 悝 with 詼諧啁調 and connects the second sense to suffering or illness.

**Final English:** To mock, tease or jest; another sense is to feel sick or distressed. Formed from 心, with 里 indicating the sound. The Spring and Autumn commentary mentions Kong Kui.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/6815.json)

### `shuowen:6822` — 憿 (jiāo) — `clear` (English revised)

**Chinese source:** 幸也。从心敫聲。

**Decision:** Duan describes 幸 as 吉而免凶, and derives later 僥倖.

**Final English:** Good fortune, particularly the luck of escaping misfortune or danger. Formed from 心, with 敫 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/6822.json)

### `shuowen:6874` — 㥋 (yī) — `clear` (English revised)

**Chinese source:** 痛聲也。从心依聲。《孝經》曰：“哭不㥋。”

**Decision:** Duan cites mourning-cry gradations in ritual texts and identifies 㥋/偯 as wavering vocalization.

**Final English:** A modulated, wavering sound of mourning or lamentation. Formed from 心, with 依 indicating the sound. The Classic of Filial Piety says: “In mourning, the cry must not be artificially modulated.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/6874.json)

### `shuowen:6919` — 惎 (jì) — `revised_retained` (English revised)

**Chinese source:** 毒也。从心其聲。《周書》曰：“來就惎惎。”

**Decision:** Duan confirms 惎 “poison, malice”, but identifies likely substantial textual loss in the quoted Documents line.

**Final English:** Malice or malicious intent. Formed from 心, with 其 indicating the sound. The Documents quotation uses a repetitive expression involving 惎, but the wording is damaged. [Duan notes the received quotation differs substantially from its parallel in the Qin Oath.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/6919.json)

### `shuowen:6932` — 憬 (jǐng) — `revised_retained` (English revised)

**Chinese source:** 覺寤也。从心景聲。《詩》曰：“憬彼淮夷。”

**Decision:** Duan reads “to awaken”, but questions whether the headword was in the original dictionary and points to alternate 詩 wording.

**Final English:** To awaken or come to understanding. Formed from 心, with 景 indicating the sound. The Odes quotation involves the Huai peoples, but the transmitted poetic graph differs from the Mao recension. [Duan suggests this entry may be a later addition.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/6932.json)

### `shuowen:6934` — 悱 (fěi) — `checked_retained`

**Chinese source:** 口悱悱也。从心非聲。

**Decision:** The entry is brief and no Duan note resolves whether 口悱悱 describes a speech blockage, agitation, or struggling to express oneself; uncertainty retained.

**Final English:** The mouth struggling to express something. Formed from 心, with 非 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/6934.json)

### `shuowen:6997` — 洭 (kuāng) — `clear` (English revised)

**Chinese source:** 水。出桂陽縣盧聚，山洭浦關爲桂水。从水匡聲。

**Decision:** Duan reconstructs the missing 南出 wording and geographically identifies the historic Kuang River water system.

**Final English:** The 洭 River, a watercourse formerly recorded as rising near Lujü in Guiyang Commandery and passing through the Kuangpu Pass; it is also called 桂水 (Gui River). Formed from 水, with 匡 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/6997.json)

### `shuowen:7045` — 沭 (shù) — `revised_retained` (English revised)

**Chinese source:** 水。出青州浸。从水术聲。

**Decision:** Duan argues the transmitted 出青州浸 has lost seven characters and supplies a parallel geographic account.

**Final English:** The Shu River, recorded as a major watercourse of Qingzhou. Duan reconstructs an omitted source description locating it in the old Dongguan region, flowing south toward the Si River. Formed from 水, with 术 indicating the sound. [The received source location is truncated.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/7045.json)

### `shuowen:7052` — 汶 (wèn) — `clear` (English revised)

**Chinese source:** 水。出琅邪朱虛東泰山，東入濰。从水文聲。桑欽說：汶水出泰山萊蕪，西南入泲。

**Decision:** Duan explicitly distinguishes East Wen River from the Yügong Wen River, with their separate watersheds.

**Final English:** The name of two historically distinguished Wen rivers: the eastern Wen, rising near Zhu Xu in Langya and flowing into the Wei, and another Wen River, rising near Laiwu on Mount Tai and flowing southwest toward the Ji River. Formed from 水, with 文 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/7052.json)

### `shuowen:7073` — 湳 (nǎn) — `revised_retained` (English revised)

**Chinese source:** 西河美稷𠈃東北水。从水南聲。

**Decision:** Duan correlates the historic hydronym with the Water Classic, but explicitly says the present-day river is unknown.

**Final English:** The old Nan River, a stream recorded as rising near Meiji in Xihe Commandery, northeast of a fortified settlement, and flowing toward the Yellow River. Formed from 水, with 南 indicating the sound. [The exact modern watercourse remains unidentified.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/7073.json)

### `shuowen:7093` — 洍 (sì) — `revised_retained` (English revised)

**Chinese source:** 水也。从水𦣞聲。《詩》曰：“江有洍。”

**Decision:** Duan distinguishes 水名 and loan reading in the poem, and notes Mao recension has 汜.

**Final English:** The name of a watercourse. Formed from 水, with 𦣞 indicating the sound. The Odes quotation uses 洍 as a textual variant of 汜 in “The river has a tributary channel.” [Duan considers the cited form a loan, not a definition of the river’s location.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/7093.json)

### `shuowen:7094` — 澥 (xiè) — `clear` (English revised)

**Chinese source:** 郣澥，海之別也。从水解聲。一說：澥即澥谷也。

**Decision:** Duan describes Bohai as a branch of the larger sea and distinguishes the separate valley-name explanation.

**Final English:** The Bohai, a great branch or inlet of the sea rather than the open sea itself. Formed from 水, with 解 indicating the sound. Another explanation refers to a valley called 澥谷.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/7094.json)

### `shuowen:7113` — 泌 (bì) — `clear` (English revised)

**Chinese source:** 俠流也。从水必聲。

**Decision:** Duan interprets 俠流 as 輕快之流 and rejects the “confined stream” interpretation.

**Final English:** A rapid or nimble-flowing stream. Formed from 水, with 必 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/7113.json)

### `shuowen:7120` — 𤃴 (huò) — `revised_retained` (English revised)

**Chinese source:** 礙流也。从水薉聲。《詩》云：“施罟𤃴𤃴。”

**Decision:** Duan reconstructs the poem as 施罛濊濊 and treats the entry 𤃴 as a later graphic corruption.

**Final English:** The turbulent, splashing movement of water where nets hinder but do not stop its flow. Formed from 水, with 薉 indicating the sound. The Odes describes fishing nets set amid rushing water. [Duan argues the true headword and poem variant are 濊 rather than the transmitted 𤃴.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/7120.json)

### `shuowen:7144` — 濫 (làn) — `clear` (English revised)

**Chinese source:** 氾也。从水監聲。一曰濡上及下也。《詩》曰：“𧥑沸濫泉。”一曰清也。

**Decision:** Duan explains the overflow, soak, and separately attested clear sense; points to original 觱沸濫泉 quotation.

**Final English:** To overflow or spread broadly. Another meaning is to soak downward from above. A further separate meaning is “clear.” Formed from 水, with 監 indicating the sound. The Odes describes a spring bubbling up and overflowing.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/7144.json)

### `shuowen:8501` — 紿 (dài) — `clear` (English revised)

**Chinese source:** 絲勞卽紿。从糸台聲。

**Decision:** Duan replaces transmitted 卽 with 則 and explains 絲勞敝則爲紿.

**Final English:** Silk thread that has become worn or exhausted through use, as though slack and fatigued. Formed from 糸, with 台 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/8501.json)

### `shuowen:8502` — 納 (nà) — `clear` (English revised)

**Chinese source:** 絲溼納納也。从糸内聲。

**Decision:** Duan confirms 納納 meaning damp/moist, citing Liu Xiang.

**Final English:** The damp, clinging appearance of wet silk, called 納納. Formed from 糸, with 内 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/8502.json)

### `shuowen:8503` — 紡 (fǎng) — `revised_retained` (English revised)

**Chinese source:** 網絲也。从糸方聲。

**Decision:** Duan directly rejects 網絲 as nonsensical in this context and restores 紡絲也; preserve source variant as uncertain.

**Final English:** To spin silk thread. Formed from 糸, with 方 indicating the sound. [The transmitted 網絲 and other recensions conflict; Duan reconstructs 紡絲也.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/8503.json)

### `shuowen:8513` — 繎 (rán) — `revised_retained` (English revised)

**Chinese source:** 絲勞也。从糸然聲。

**Decision:** Duan contrasts 勞 and 縈, and describes tangled silk; retain text uncertainty.

**Final English:** Silk thread worn or entangled through handling. Formed from 糸, with 然 indicating the sound. [Duan proposes that 勞 may be an error for 縈, “entwined”.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/8513.json)

### `shuowen:8518` — 緢 (miáo) — `revised_retained` (English revised)

**Chinese source:** 旄絲也。从糸苗聲。《周書》曰：“惟緢有稽。”

**Decision:** Duan identifies 犛牛 tail hair and notes differences between 緢 and later 貌 in the Documents quotation.

**Final English:** Fine tail hairs from a yak or similar bovine, used like silk for ornaments. Formed from 糸, with 苗 indicating the sound. The Documents quotation uses an old graph in a passage about exact scrutiny. [The transmitted 旄 and quotation differ from Duan’s proposed 氂 and another textual reading.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/8518.json)

### `shuowen:8519` — 縒 (cī) — `clear` (English revised)

**Chinese source:** 參縒也。从糸差聲。

**Decision:** Duan identifies 參差 irregularity and comments on the textile sense.

**Final English:** Uneven or disordered strands of silk, as in the phrase 參縒 (“of unequal length”). Formed from 糸, with 差 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/8519.json)

### `shuowen:8520` — 繙 (fán) — `revised_retained` (English revised)

**Chinese source:** 冕也。从糸番聲。

**Decision:** Duan argues 冕 is a miscopy of 冤 and cites 繙冤/繙亂, but the accepted reading is edition-dependent.

**Final English:** Tangled or disordered silk, in a rare old expression. Formed from 糸, with 番 indicating the sound. [The received 冕 (“ceremonial cap”) is disputed; Duan reconstructs an older expression meaning disorder.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/8520.json)

### `shuowen:8531` — 缳 (xuàn) — `clear` (English revised)

**Chinese source:** 落也。从糸瞏聲。

**Decision:** Duan reads 落 as a loan for 絡, “wrap around”, and cites classical uses of winding/encircling.

**Final English:** To encircle, wrap or bind around, as with a cord. Formed from 糸, with 瞏 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/8531.json)

### `shuowen:9310` — 鉊 (zhāo) — `revised_retained` (English revised)

**Chinese source:** 大𨮯也。从金召聲。鎌謂之鉊，張徹說。

**Decision:** Duan cites 方言 for 錐 “awl”, while the received source says 鎌 “sickle”; do not force one identification.

**Final English:** A metal implement, possibly an awl or sickle, with a regional designation 鉊. Formed from 金, with 召 indicating the sound. [Duan notes disagreement among 方言, 廣雅 and the received text over the precise implement.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9310.json)

### `shuowen:9313` — 鉆 (chān) — `clear` (English revised)

**Chinese source:** 𨮯銸也。从金占聲。一曰膏車𨮯鉆。

**Decision:** Duan identifies an implement used to insert grease into a carriage hub.

**Final English:** Metal pincers or tongs; alternatively, a metal fitting or tool used to apply grease within the axle hub of a vehicle. Formed from 金, with 占 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9313.json)

### `shuowen:9317` — 鋸 (jù) — `clear` (English revised)

**Chinese source:** 槍唐也。从金居聲。

**Decision:** Duan explains 槍唐 as an old Han designation for the saw and cites early literary testimony.

**Final English:** A saw, called 槍唐 in an older regional term. Formed from 金, with 居 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9317.json)

### `shuowen:9326` — 銖 (zhū) — `revised_retained` (English revised)

**Chinese source:** 權十分黍之重也。从金朱聲。

**Decision:** Duan explains 十絫黍 (ten multiples of ten millet grains), with Han weight standards; user source lacks 絫.

**Final English:** A zhū, an ancient unit of weight equivalent in one Han-era standard to 100 millet grains (24 zhū to one liǎng). Formed from 金, with 朱 indicating the sound. [The transmitted “ten parts of millet” is defective; Duan reconstructs 十絫黍.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9326.json)

### `shuowen:9332` — 鈀 (bā) — `revised_retained` (English revised)

**Chinese source:** 兵車也。一曰𨮯也。《司馬法》：“晨夜内鈀車。”从金巴聲。

**Decision:** Duan notes the quotation is absent from received 司馬法 and cites a thin metal blade from 方言.

**Final English:** A military carriage, according to one gloss; alternatively, a metal tool. The Methods of the Sima mentions bringing in 鈀 carriages. Formed from 金, with 巴 indicating the sound. [The quotation does not survive in the extant Sima Fa, and other sources describe a metal bladed implement.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9332.json)

### `shuowen:9338` — 鑮 (bó) — `revised_retained` (English revised)

**Chinese source:** 大鐘，湻于之屬，所以應鐘磬也。堵以二，金樂則鼓鏄應之。从金薄聲。

**Decision:** Duan extensively distinguishes this large bell from the 錞于 drum-accompaniment and corrects the orchestral measure.

**Final English:** A large, separately suspended musical bell that responds to sets of bells and stone chimes, likened to a 錞于. Formed from 金, with 薄 indicating the sound. [The passage on the number of bell-and-chime sets contains transmitted errors; Duan proposes a reconstruction.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9338.json)

### `shuowen:9341` — 鈁 (fāng) — `clear` (English revised)

**Chinese source:** 方鐘也。从金方聲。

**Decision:** Duan confirms 方鐘, and notes a later secondary sense.

**Final English:** A square-shaped bronze bell or bell-shaped metal vessel. Formed from 金, with 方 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9341.json)

### `shuowen:9342` — 鎛 (bó) — `clear` (English revised)

**Chinese source:** 鎛鱗也。鐘上橫木上金華也。一曰田器。从金尃聲。《詩》曰：“庤乃錢鎛。”

**Decision:** Duan distinguishes ornate bell-beam plating 鎛鱗 from hoe used to weed fields.

**Final English:** A metal floral ornament attached to the wooden beam above suspended bells; alternatively, an agricultural hoe. Formed from 金, with 尃 indicating the sound. The Odes says: “Prepare your spades and hoes.”

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9342.json)

### `shuowen:9345` — 鏓 (cōng) — `revised_retained` (English revised)

**Chinese source:** 鎗鍃也。一曰大鑿，平木者。从金悤聲。

**Decision:** Duan cites a bell-sound usage and argues that a large chisel penetrates timber rather than planes it flat.

**Final English:** A resonant clang or clash, as of a bell. Alternatively, a large chisel used to cut into timber. Formed from 金, with 悤 indicating the sound. [Duan disputes the transmitted 平木者 and reconstructs 中木, “boring into wood”.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9345.json)

### `shuowen:9349` — 鐔 (xín) — `clear` (English revised)

**Chinese source:** 劒鼻也。从金覃聲。

**Decision:** Duan identifies 鐔 with sword hilt end 劒首 and distinguishes it from blade edge and sword body.

**Final English:** The metal end or pommel of a sword hilt, with a projection or opening, traditionally called its “nose.” Formed from 金, with 覃 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9349.json)

### `shuowen:9352` — 鏢 (biāo) — `clear` (English revised)

**Chinese source:** 刀削末銅也。从金㶾聲。

**Decision:** Duan explains 削 as a knife sheath and 鏢 as its metal terminal fitting.

**Final English:** A copper or bronze end fitting on a knife sheath, rather than the knife blade itself. Formed from 金, with 㶾 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9352.json)

### `shuowen:9360` — 錞 (duì) — `clear`

**Chinese source:** 矛𢧢柲下銅，鐏也。从金𦎫聲。《詩》曰：“叴矛沃𨯢。”

**Decision:** The source directly identifies the copper butt-cap/ferrule of a spear shaft; existing English reflects it.

**Final English:** The bronze below the shaft of a spear or halberd: a butt ferrule. Formed from 金, with 𦎫 indicating the sound. The Odes says: 'Three-edged spears with gleaming ferrules.'

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9360.json)

### `shuowen:9362` — 鏐 (liú) — `clear` (English revised)

**Chinese source:** 弩眉也。一曰黃金之美者。从金翏聲。

**Decision:** Duan links second sense to gold of high purity and cites historical sources.

**Final English:** A fitting at the “brow” of a crossbow; alternatively, exceptionally fine gold. Formed from 金, with 翏 indicating the sound.

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9362.json)

### `shuowen:9363` — 𨩀 (hóu) — `revised_retained` (English revised)

**Chinese source:** 矢。金鏃翦羽謂之鏃。从金矦聲。

**Decision:** Duan examines 矢、金鏃、翦羽 and recommends removing the entry or restoring 族; preserve transmitted text.

**Final English:** An arrow with a metal head and trimmed fletching, described in traditional arrow typology. Formed from 金, with 矦 indicating the sound. [Duan argues this entry is absent from the earlier Xiao Xu edition and that the received explanatory headword 鏃 is corrupt.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9363.json)

### `shuowen:9371` — 銴 (shì) — `revised_retained` (English revised)

**Chinese source:** 車樘結也。一曰銅生五色也。从金折聲。讀若誓。

**Decision:** Duan states the precise vehicle fitting is 未詳 but confirms basic semantic category and patination.

**Final English:** A metal joint or fastening associated with the bracing of a carriage frame; alternatively, the multicolored patina that develops on bronze. Formed from 金, with 折 indicating the sound. Pronounced like 誓. [The exact form of the carriage fixture remains unknown.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9371.json)

### `shuowen:9372` — 釳 (xì) — `revised_retained` (English revised)

**Chinese source:** 乘輿馬頭上防𨥊。插以翟尾、𨮯翮，象角。所以防綱羅𨥊去之。从金气聲。

**Decision:** Duan cites competing descriptions from horse-harness records, distinguishing placement and shape.

**Final English:** A horn-like metal anti-entanglement fitting on an imperial carriage horse, decorated with pheasant-tail feathers to deflect nets or dangling gear. Formed from 金, with 气 indicating the sound. [Sources differ on whether the fitting sat on the horse’s head or near the front of the carriage pole.]

**Evidence:** [Source 1](https://github.com/shuowenjiezi/shuowen/blob/master/data/9372.json)


## Integration instructions for author agent

1. The authoritative complete output for this pass is `shuowen-english-external-reviewed-v3.txt` (9,833 keys). The separate `shuowen-remaining-uncertain-v3.txt` is a **subset**, not a patch of resolved entries.

2. To merge into a different master, apply `shuowen-884-resolution-patch-v3.jsonl` by stable `shuowen:<number>` key, replacing English and removing `[UNCERTAIN]` **only** when status is `clear`. Avoid re-adding flags to already resolved entries.

3. Do not overwrite editorial Chinese source strings; a comment about a textual corruption is **not** permission to replace the received Chinese in place.

4. The CSV lists all 884 prior uncertain entries with exactly one status per row. The remaining `not_checked_this_pass` rows are the outstanding substantive research queue.

5. Do not treat the English translation revisions as an endorsement of Xu Shen’s Han-era glyph etymologies by present-day paleography.
