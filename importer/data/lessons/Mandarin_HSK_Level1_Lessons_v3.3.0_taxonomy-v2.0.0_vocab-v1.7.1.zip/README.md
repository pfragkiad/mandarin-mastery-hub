# HSK 3.0 Level 1 lessons — Core v3.3.0, taxonomy v2.0.0, vocabulary v1.7.1

The 21 teaching lessons are synchronized with the 300-word `hsk3_level1_1.7.1.json` source. Each lesson ZIP contains exactly four files: JSON, HTML, Markdown, and `report.md`.

- 33 word-card example sentence records refreshed in 15 lessons; 3 dependent production questions updated.
- The Level 1 curriculum description is learner-facing and does not contain workflow details.
- Progress checkpoint identifiers and required/optional flags are unchanged; only labels for the three updated production questions were refreshed.
- Exception: the source's incorrectly segmented pinyin for `电脑` (`diànnǎo`) was NOT copied; the existing corrected lesson reading was retained.
- Source and editorial audit files are in `audits/` and separate from learner-facing lessons.
- The individual vocabulary source file is not embedded in this lesson archive; source IDs and course placement are preserved.

This replaces `Mandarin_HSK_Level1_Lessons_v3.3.0_taxonomy-v2.0.0.zip`.
