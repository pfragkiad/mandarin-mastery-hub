# Conversational Mandarin — independent topic lessons

**Course:** `conversational-mandarin` · 15 complete beginner teaching lessons.

The communicative themes were selected by the learner. Lesson content is independently authored for this project; a shared topic does not imply that any third-party course text was copied. The course is not presented as a transcription or reorganization of another course's recorded lessons.

## Contents

- `topics/`: 15 completed lesson ZIPs, each containing **exactly four root-level files** (`.json`, `.html`, `.md`, `report.md`).
- `../curricula/CONVERSATIONAL_MANDARIN.json`: independent course curriculum and existing lesson placements.
- `BROWSE_BY_TOPIC.html`: offline Kai-style Hanzi / pinyin search and topical browsing, without source-track information.
- `TOPIC_LESSON_INDEX.json`: course lesson index with global topics and subtopics.
- `QUALITY_REPORT.json`: integrity and structural-validation summary.
- `REPORT.md`: editorial scope, quality policy and change details.

## Authoring and distribution rules

- Preserve stable lesson IDs, practice questions, dialogue turns, and all authored instructional content.
- The global taxonomy is **v2.0.0**, with 22 active topics and 25 active subtopics.
- The current Core JSON Schema package remains **v3.2.0**; the general/dialogue schema is `mandarin-general-lesson/3.1.0`, with older versions still supported.
- The curriculum schema remains `mandarin-curriculum/3.0.0`.
- Source transcription datasets and timestamp indexes are *not part of the distributed independent teaching collection*. Older user-held archives are not modified.
- No claim of independent native-speaker certification or original ownership of routine, conventional Mandarin phrases is made.

## Lesson topics

1. Asking Where Places Are (16 key expression placements)
2. Choosing: Or, Either, and Not (14 key expression placements)
3. Clock Time and Negotiating a Meeting (16 key expression placements)
4. Ordering Food and Drinks (16 key expression placements)
5. Greetings and Politeness (11 key expression placements)
6. Money, Prices, and Currency (16 key expression placements)
7. Counting and Simple Arithmetic (16 key expression placements)
8. Introducing Yourself and Other People (17 key expression placements)
9. Permission and Polite Requests (16 key expression placements)
10. Choosing Where to Meet and Eat (15 key expression placements)
11. Speaking Languages and Describing Ability (16 key expression placements)
12. Today, Tomorrow, and Later (17 key expression placements)
13. Understanding and Asking for Clarification (13 key expression placements)
14. Expressing Wants and Intentions (16 key expression placements)
15. Doing Things Together (12 key expression placements)
