# Conversational Mandarin — editorial correction and verification

## Scope

This release corrects misleading course attribution. Conversational topics were selected as thematic study goals, while the lesson dialogues and exercises were authored for the independent Mandarin Tutor project. An earlier package packaged third-party timed transcript/source extraction indexes as though they were the provenance of the new lessons. The independent lesson release no longer makes that assertion.

## Retained content

- All 15 permanent lesson IDs.
- All 60 dialogue turns, 227 key expression placements, and 60 practice questions.
- Every canonical lesson JSON, HTML and Markdown is byte-identical to the latest input version (including the two subsequently synchronized lesson packages).
- Curriculum section/unit structure, placement IDs, ordering, prerequisites, and course topics.

## Revised ancillary material

- Every individual `report.md`: independent editorial provenance and actual package counts, no third-party claims or source timestamps.
- Curriculum description and edition: independent topics, no audio-track/source-course claims.
- Browser: removed source-track timestamps and attribution strings; retained topic search, Chinese/pinyin, expression lists and practice conversations.
- Topic lesson index: removed `source_tracks`, synchronized global topic and subtopic references.
- Project README and quality report: corrected to independent authorship; only verified facts about delivered content included.
- Excluded historical transcript texts and extraction-review index from this independent lesson package; the input archives remain untouched.

## Validated

- 15 complete four-file nested lesson ZIPs; ZIP CRC checks passed.
- All 15 canonical lesson JSON files validate against the unchanged general lesson JSON Schema.
- Curriculum JSON validates against the unchanged curriculum JSON Schema.
- All course-lesson placements continue to refer to existing stable lesson IDs.
- No forbidden course attribution appears in the distributed Core templates or independent lesson package.
- No native-speaker linguistic certification is claimed; structural checks are not a substitute for such editorial review.
