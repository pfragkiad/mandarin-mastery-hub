# Other Mandarin lessons — checkpoint enabled

15 Conversational Mandarin and 2 independent character usage lessons. Non-time-based learner checkpoint definitions in JSON. Independent of any third-party course.
