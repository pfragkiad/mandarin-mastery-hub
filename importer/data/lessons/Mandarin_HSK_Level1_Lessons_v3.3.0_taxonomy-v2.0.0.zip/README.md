# HSK Level 1 teaching lessons — progress checkpoints

21 instructional lessons. Each preserves authored teaching content and contains canonical progress checkpoints with stable IDs. The HSK curriculum placement is unchanged.
