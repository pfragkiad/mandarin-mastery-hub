# HSK Level 2 — complete course release and validation report

## Release identity

- Core/lesson schema: **v3.3.0**, unchanged.
- Taxonomy: **v2.0.0**, 22 registered active topics and 25 available optional subtopics.
- Source: **hsk3_level2_1.1.1.json**, data v1.1.1, ID range **301–500**, 200 distinct entries.
- Level 1 review source: v1.7.1.
- Source SHA-256: `3b1fdb54b150f48550b8a0276098206fcf80274fcf956f18f9d34f832f804f50`.
- Scope: **25 complete topic teaching lesson ZIPs**, 20 distinct populated primary topics.
- Curriculum: original Level 1 21 placements retained verbatim in an extended Level 1+2 curriculum with 25 Level 2 placements.

## Complete topic lesson plan

| No. | Primary topic | Lesson | New IDs | Intro count | Core / bonus checkpoints |
|---:|---|---|---|---:|---:|
| 1 | `people-identity` | Introducing People by Name | 344, 410, 412, 461, 464, 465 | 6 | 15 / 3 |
| 2 | `family-relationships` | Talking About Family Members | 409, 417, 470, 487 | 4 | 15 / 3 |
| 3 | `communication-social` | Asking for Help and Making Introductions | 306, 313, 343, 369, 422, 463 | 6 | 15 / 3 |
| 4 | `reference-questions` | Explaining Why and How | 406, 407, 454, 488, 489, 494 | 6 | 15 / 3 |
| 5 | `school-language` | Words, Classes and Examinations | 304, 308, 310, 322, 337, 342, 367, 368, 379, 380, 381, 442 | 12 | 15 / 3 |
| 6 | `time-calendar` | Talking About Time and Habits | 325, 349, 374, 378, 386, 430, 431, 462, 471, 480, 492 | 11 | 15 / 3 |
| 7 | `numbers-quantities` | Counting Things and Occasions | 323, 366, 399, 404, 443, 449, 453 | 7 | 15 / 3 |
| 8 | `food-drink` | Choosing Drinks and Food | 336, 339, 354, 377, 395, 408, 423, 483 | 8 | 15 / 3 |
| 9 | `shopping-money` | Buying Tickets and Shopping | 357, 402, 424 | 3 | 15 / 3 |
| 10 | `home-objects` | My Room and My Belongings | 307, 321, 383, 400, 434, 435 | 6 | 15 / 3 |
| 11 | `places-directions` | Places, Position & Direction — Part 1: Describing Location and Distance | 356, 371, 389, 390, 391, 403, 413, 419, 426, 447, 459, 481, 482, 484, 499, 500 | 16 | 15 / 3 |
| 12 | `places-directions` | Places, Position & Direction — Part 2: Entering, Leaving and Returning | 316, 318, 320, 347, 348, 350, 361, 362, 370, 372, 373, 425, 427, 458, 460 | 15 | 15 / 3 |
| 13 | `places-directions` | Places, Position & Direction — Part 3: Finding the Way in Town | 324, 392, 401, 446, 450, 457 | 6 | 15 / 3 |
| 14 | `travel-transport` | Planning a Journey | 315, 317, 328, 335, 346, 363, 364, 375, 393, 394, 416, 486 | 12 | 15 / 3 |
| 15 | `daily-actions` | Daily Actions & Activities — Part 1: Helping with Everyday Tasks | 305, 329, 334, 338, 405, 418, 437, 456 | 8 | 15 / 3 |
| 16 | `daily-actions` | Daily Actions & Activities — Part 2: Routines and Making Plans | 319, 365, 414, 448, 452, 473, 493, 495, 496 | 9 | 15 / 3 |
| 17 | `health-wellbeing` | How Are You Feeling? | 388, 415, 429, 433, 436, 440, 445, 467, 468, 469, 478, 485 | 12 | 15 / 3 |
| 18 | `animals-weather` | Nature and the Weather | 340, 358, 411, 420, 475, 477 | 6 | 15 / 3 |
| 19 | `leisure-media` | Sports, Games and Hobbies | 302, 327, 359, 387, 421, 441, 444, 497 | 8 | 15 / 3 |
| 20 | `qualities-feelings` | Qualities, Feelings & Evaluation — Part 1: Describing Colors and Comparing Things | 303, 309, 314, 341, 353, 355, 360, 384, 396, 397, 466 | 11 | 15 / 3 |
| 21 | `qualities-feelings` | Qualities, Feelings & Evaluation — Part 2: Sharing Opinions and Feelings | 312, 326, 385, 398, 455, 479 | 6 | 15 / 3 |
| 22 | `grammar-functions` | Grammar & Function Words — Part 1: Linking Ideas in Conversation | 330, 331, 345, 352, 376, 382, 438, 439, 476 | 9 | 15 / 3 |
| 23 | `grammar-functions` | Grammar & Function Words — Part 2: Describing Actions More Precisely | 301, 311, 332, 333, 351, 472, 490, 491, 498 | 9 | 15 / 3 |
| 24 | `abstract-concepts` | Talking About Meanings and Situations | 432, 474 | 2 | 15 / 2 |
| 25 | `science-technology` | Using the Internet | 428, 451 | 2 | 15 / 2 |

## Release checks

- PASS: **200/200** HSK Level 2 entries introduced in exactly one lesson; no missing, duplicate or substituted source IDs.
- PASS: word-bank headword, pinyin, POS, exact source example triples and original topic/subtopic IDs match v1.1.1.
- PASS: all 25 lessons validated using `validate_core.py --lesson … --catalog-ids …`, plus explicit progress target and taxonomy checks.
- PASS: 25 nested lesson ZIPs with exactly four root files (JSON, HTML, Markdown, report.md).
- PASS: Level 1 original curriculum section deep-equal to the previous released curriculum; 21 placements not replaced.
- PASS: full combined curriculum checked with all 46 lesson JSON files available.
- PASS: no Core templates or JSON schemas modified.
- DOCUMENTED SOURCE EXCEPTION: Level 1 review entry #36 电脑 (diànnǎo), example 1 pinyin word boundaries corrected from `shàngxué xí` to `shàng xuéxí` in the lesson only; original v1.7.1 source remains unchanged.
- EDITORIAL CORRECTION: Replaced word-card sentence reuse in Movement and Direction and Abstract Concepts. Authored dialogue/practice is now checked for exact word-card sentence duplicates.
- Checkpoints: **375 required** and **73 optional**, independent of time.
- Character IDs absent from the external catalog (no IDs fabricated): `none`.

## Important import notes

- Import every `hsk3/level2/TOPIC_LESSON_*.zip` as a complete lesson; do not import the old one-off “Making Plans Together” as a substitute for this set.
- Use `curricula/HSK3_2025_LEVEL1_LEVEL2.json` to add Level 2 to the existing HSK curriculum without deleting the 21 Level 1 placements.
- Each topic lesson introduces only the Level 2 words assigned to that topic; its separate teaching examples may naturally reuse words from other completed lessons.
- The course-level ZIP is the complete deliverable; none of the 25 nested lesson ZIPs alone is a complete HSK Level 2 course.
- Lessons remain **draft** pending human/native-speaker review of naturalness and phonetic details; automated checks establish structural and source integrity, not complete linguistic certification.
