# Conversational Mandarin + independent character lessons — Core v3.3.0

15 Conversational Mandarin lessons have reader-friendly introductory text and checkpoint labels, with immutable lesson IDs, checkpoint IDs, and quiz logic. No outside course is presented as the source of authored teaching content. Technical provenance remains exclusively in the individual `report.md` files. The two independent character lesson ZIPs are unchanged.
